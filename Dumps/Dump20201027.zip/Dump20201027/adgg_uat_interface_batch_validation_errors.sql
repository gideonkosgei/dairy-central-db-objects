-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: adgg_uat
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `interface_batch_validation_errors`
--

DROP TABLE IF EXISTS `interface_batch_validation_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interface_batch_validation_errors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `error_check` varchar(50) DEFAULT NULL,
  `error_condition` varchar(250) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interface_batch_validation_errors`
--

LOCK TABLES `interface_batch_validation_errors` WRITE;
/*!40000 ALTER TABLE `interface_batch_validation_errors` DISABLE KEYS */;
INSERT INTO `interface_batch_validation_errors` VALUES (1,'','','2020-08-26 11:37:31',559,NULL,NULL),(2,'milk_max_amount','Milk Max Amount Limit Exceeded','2020-08-26 11:39:36',559,NULL,NULL),(3,'milk_min_amount','Milk Amount Below Limit','2020-08-26 11:41:13',559,NULL,NULL),(4,'animal_existence_check','Animal not in found','2020-08-26 11:42:56',559,NULL,NULL),(5,'calving_details_check','Calving Details Not found','2020-08-26 11:49:48',559,NULL,NULL),(6,'lactation_details_check','Lactation Details Not found','2020-08-26 11:50:13',559,NULL,NULL),(7,'milking_status','Animal Not In Milk','2020-08-26 11:50:15',559,NULL,NULL);
/*!40000 ALTER TABLE `interface_batch_validation_errors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-27 10:16:28
