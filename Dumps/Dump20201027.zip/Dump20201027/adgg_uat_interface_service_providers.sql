-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: adgg_uat
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `interface_service_providers`
--

DROP TABLE IF EXISTS `interface_service_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interface_service_providers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `acronym` varchar(255) DEFAULT NULL,
  `service_provider_type` int DEFAULT NULL,
  `country` int DEFAULT NULL,
  `postal_address` varchar(255) DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `services_offered` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_person_mobile_number` varchar(255) DEFAULT NULL,
  `org_id` int DEFAULT NULL,
  `farm_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interface_service_providers`
--

LOCK TABLES `interface_service_providers` WRITE;
/*!40000 ALTER TABLE `interface_service_providers` DISABLE KEYS */;
INSERT INTO `interface_service_providers` VALUES (1,'Kenya Agricultural and Livestock Research Organization','Kalro',1,11,'1226','30100','Eldoret','0720000000','Test@Test.com','KALRO is a corporate body created under the Kenya Agricultural and Livestock Research Act of 2013 to establish suitable legal and institutional framework for coordination of agricultural research in Kenya','AI, breeding','Tony Love','0700000000',5,NULL,559,'2020-09-29 12:19:26',NULL,NULL),(2,'International Livestock Research Institute','ILRI',1,11,'1226','30100','Nairobi','0720000000','Test@Test.com','International Livestock Research Institute','Research, Genotyping,AI, breeding','Bruce Lee','0700000000',5,NULL,559,'2020-09-29 15:17:03',559,'2020-09-30 09:10:13'),(3,'International Livestock Research Institute','ILRI',1,11,'1226','30100','Eldoret','0720000000','Test@Test.com','International Livestock Research Institute','Research, Genotyping,AI, breeding','Bruce Lee','0700000000',5,NULL,559,'2020-09-29 15:46:19',NULL,NULL),(4,'International Livestock Research Institute','ILRI',1,11,'1226','30100','Eldoret','0720000000','Test@Test.com','International Livestock Research Institute','Research, Genotyping,AI, breeding','Bruce Lee','0700000000',5,NULL,559,'2020-09-29 15:47:10',NULL,NULL),(5,'International Livestock Research Institute','ILRI',1,11,'1226','30100','Nairobi','0720000000','Test@Test.com','International Livestock Research Institute','Research, Genotyping,AI, breeding','Bruce Lee','0700000000',5,NULL,559,'2020-09-29 15:57:01',559,'2020-10-02 05:32:36'),(6,'Kenya Animal Genetic Resources Centre','KAGRIC',1,11,'23070','00604','NAIROBI','0786204400','info@kagrc.co.ke','The Kenya Animal Genetic Resources Centre (KAGRC)  was established by Kenya Gazette Notice Number 557 of 19th June 1946 with the objective of controlling venereal diseases and genetic improvement of exotic dairy Cattle','Sale of Bull Semen\nExtension Services\nSale of AI Equipment\nTesting of Liquid Nitrogen Containers\nCryo Conservation\nProduction of Liquid Nitrogen','Dr. Kios','0786204400',5,NULL,559,'2020-09-30 08:40:00',559,'2020-09-30 09:17:43');
/*!40000 ALTER TABLE `interface_service_providers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-27 10:16:26
