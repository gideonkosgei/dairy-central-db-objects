-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: adgg_uat
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'adgg_uat'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_agent_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_agent_create`(_name varchar(255),_occupation varchar(255), _affiliation int, _country int,_physical_address varchar(255),postal_address varchar(255), _postal_code varchar(255), _city varchar(255), _phone varchar(255),_email varchar(255), _speciality varchar(255),  _org_id int, _created_by int)
BEGIN  
   INSERT INTO interface_agents (name,occupation,affiliation,country,physical_address,postal_address,postal_code,
   city,phone,email,speciality,org_id,created_at,created_by)
   values (_name, _occupation, _affiliation, _country,_physical_address,postal_address, _postal_code, _city, _phone,_email, _speciality,_org_id, now(), _created_by);
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_agent_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_agent_update`(_id int,_name varchar(255),_occupation varchar(255), _affiliation int, _country int,_physical_address varchar(255),_postal_address varchar(255), _postal_code varchar(255), _city varchar(255), _phone varchar(255),_email varchar(255), _speciality varchar(255), _updated_by int)
BEGIN  
   UPDATE interface_agents SET name = _name ,occupation = _occupation ,affiliation = _affiliation,country = _country,physical_address = _physical_address,postal_address = _postal_address,postal_code = _postal_code,
   city = _city,phone = _phone,email = _email,speciality = _speciality,updated_at = now(),updated_by = _updated_by
   WHERE id  = _id;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_agent_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_agent_view`(_id int,_option int)
BEGIN
   /* 
     options
     ------------
      value   	Description
       0  		view all records that belong to an org/farm. _id paramer value is org id
       1        view a specific record. _id paramer value is record id
   
   */
   IF _option = 0 THEN
	SELECT 
		sp.id, 
        sp.name,
        sp.occupation,
        sp.postal_address,
        sp.physical_address,
        sp.postal_code,
        sp.city,
        sp.phone,
		sp.email,         
        sp.speciality,       
		DATE_FORMAT(sp.created_at,'%Y-%m-%d') as created_at,
		DATE_FORMAT(sp.updated_at,'%Y-%m-%d') as updated_at,		
		sp.affiliation as affiliation_id,
		aff.name as affiliation_name,
		cnt.name as country,
        sp.country as country_id,
		updated.name updated_by,    
		auth_users.name as created_by 
	FROM interface_agents sp
	LEFT JOIN core_country cnt ON cnt.id = sp.country
	LEFT JOIN auth_users ON sp.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON sp.updated_by = updated.id
    LEFT JOIN interface_service_providers aff on aff.id = sp.affiliation
	WHERE sp.org_id = _id;		
  ELSE  
	SELECT sp.id, 
        sp.name,
		sp.occupation,
        sp.postal_address,
        sp.physical_address,
        sp.postal_code,
        sp.city,
        sp.phone,
		sp.email,         
        sp.speciality,       
		DATE_FORMAT(sp.created_at,'%Y-%m-%d') as created_at,
		DATE_FORMAT(sp.updated_at,'%Y-%m-%d') as updated_at,		
		sp.affiliation as affiliation_id,
		aff.name as affiliation_name,
		cnt.name as country,
        sp.country as country_id,
		updated.name updated_by,    
		auth_users.name as created_by 
	FROM interface_agents sp
	LEFT JOIN core_country cnt ON cnt.id = sp.country
	LEFT JOIN auth_users ON sp.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON sp.updated_by = updated.id
    LEFT JOIN interface_service_providers aff on aff.id = sp.affiliation
	WHERE sp.id = _id;
  END IF;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_ai_straws_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ai_straws_view`(_id int,_option int, _is_active int)
BEGIN
   /* 
     options
     ------------
      value   	Description
       0  		view all records that belong to an org/farm. _id paramer value is org id
       1        view a specific record. _id paramer value is record id
   
   */
   IF _option = 0 THEN
	SELECT
		ai.id, 
        ai.straw_id,
        ai.barcode,
        ai.bull_tag_id,
        ai.bull_name,
        ai.breed as breed_id,
        (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 8) AND (list.value = ai.breed))) AS breed, 
        ai.breed_composition as breed_composition_id,
		(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 14) AND (list.value = ai.breed_composition))) AS breed_composition, 
        ai.semen_source,
        ai.farm_name,
        ai.batch_number,
        ai.ejaculation_number,        
        DATE_FORMAT(ai.production_date,'%Y-%m-%d') as production_date,
        ai.specification as specification_id,
        (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 85) AND (list.value = ai.specification))) AS specification, 
        ai.is_active,
		ai.is_active as  is_active_placeholer,
        ai.additional_info,		     
        DATE_FORMAT(ai.created_at,'%Y-%m-%d') as created_at,
		DATE_FORMAT(ai.updated_at,'%Y-%m-%d') as updated_at, 
		updated.name updated_by,    
		auth_users.name as created_by 
	FROM interface_ai_straws ai	
	LEFT JOIN auth_users ON ai.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON ai.updated_by = updated.id
	WHERE ai.org_id = _id and is_active = _is_active;			
  ELSE  
	SELECT
		ai.id, 
        ai.straw_id,
        ai.barcode,
        ai.bull_tag_id,
        ai.bull_name,
        ai.breed as breed_id,
        (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 8) AND (list.value = ai.breed))) AS breed, 
        ai.breed_composition as breed_composition_id,
		(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 14) AND (list.value = ai.breed_composition))) AS breed_composition, 
        ai.semen_source,
        ai.farm_name,
        ai.batch_number,
        ai.ejaculation_number,
        DATE_FORMAT(ai.production_date,'%Y-%m-%d') as production_date,
        ai.specification as specification_id,
        (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 85) AND (list.value = ai.specification))) AS specification, 
        ai.is_active,
        ai.is_active as  is_active_placeholer,
        ai.additional_info,		     
        DATE_FORMAT(ai.created_at,'%Y-%m-%d') as created_at,
		DATE_FORMAT(ai.updated_at,'%Y-%m-%d') as updated_at, 
		updated.name updated_by,    
		auth_users.name as created_by 
	FROM interface_ai_straws ai	
	LEFT JOIN auth_users ON ai.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON ai.updated_by = updated.id		
	WHERE ai.id = _id;
  END IF;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_ai_straw_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ai_straw_create`(_straw_id varchar(255), _barcode varchar(255), _bull_tag_id varchar(255), _bull_name varchar(255), _breed integer, _breed_composition integer, _semen_source varchar(255), _farm_name varchar(255),
  _batch_number varchar(255), _ejaculation_number varchar(255), _production_date datetime, _specification varchar(10), _additional_info varchar(255), _org_id integer, _created_by integer)
BEGIN  
   INSERT INTO interface_ai_straws (straw_id, barcode, bull_tag_id, bull_name, breed, breed_composition, semen_source, farm_name,
  batch_number, ejaculation_number, production_date, specification,is_active, additional_info, org_id, created_by,created_at)
 values (_straw_id, _barcode, _bull_tag_id, _bull_name, _breed, _breed_composition, _semen_source, _farm_name,
  _batch_number, _ejaculation_number, _production_date, _specification,1, _additional_info, _org_id, _created_by,now());
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_ai_straw_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ai_straw_update`(_record_id integer,_straw_id varchar(255), _barcode varchar(255), _bull_tag_id varchar(255), _bull_name varchar(255), _breed integer, _breed_composition integer, _semen_source varchar(255), _farm_name varchar(255),
  _batch_number varchar(255), _ejaculation_number varchar(255), _production_date datetime, _specification varchar(10), _additional_info varchar(255), _updated_by integer,_is_active tinyint)
BEGIN  
   UPDATE interface_ai_straws 
   SET straw_id = _straw_id, barcode = _barcode, bull_tag_id = _bull_tag_id, bull_name = _bull_name, breed = _breed, breed_composition = _breed_composition, semen_source = _semen_source, farm_name = _farm_name,
   batch_number = _batch_number, ejaculation_number = _ejaculation_number, production_date = _production_date, specification = _specification, additional_info = _additional_info, updated_by = _updated_by, updated_at = now(),is_active = _is_active
   WHERE id  = _record_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_animal_organization_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_animal_organization_view`(_org_id integer,status_id integer)
BEGIN
	/*    
		0. Animals that have exited the herd
		1. Active Animals    
    */
    
    IF status_id = 1 THEN  
		SELECT 
			core_animal.id as animal_id,
			core_animal.name as animal_name,
			core_animal.herd_id,
			herd.name as herd_name,
			core_animal.org_id,
			core_animal.sex as sex_id,
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 3) AND (list.value = core_animal.sex))) AS sex,              
			core_animal.tag_id,
			core_animal.farm_id,
			core_animal.sire_type as sire_type_id,
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 13) AND (list.value = core_animal.sire_type))) AS sire_type,              
			core_animal.sire_id,
			core_animal.sire_tag_id,
			core_animal.dam_id,
			core_animal.dam_tag_id,
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."91"')),'null','') AS aproximateage, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."225"')),'null','') AS animalGrade, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."226"')),'null','') AS notes, 
			core_animal.animal_photo AS animalPhoto, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."57"')),'null','') AS tagPrefix, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."58"')),'null','') AS tagSequence, 
			ifnull(core_animal.animal_type,0) AS animal_type_id,
			ifnull((SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 62) AND (list.value = core_animal.animal_type))),'Uncategorized') AS animalType, 
			DATE_FORMAT(core_animal.reg_date, '%Y-%m-%d') as registration_date, 
			DATE_FORMAT(core_animal.birthdate, '%Y-%m-%d') as dateofBirth,      
			core_animal.main_breed AS main_breed_id,
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 8) AND (list.value = core_animal.main_breed))) AS main_breed, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."147"')),'null','') AS breedCombination, 
			core_animal.breed_composition AS breedComposition_id, 
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 14) AND (list.value = core_animal.breed_composition))) AS breedComposition, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."223"')),'null','') AS breedCompositiondetails, 
			JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."254"')) AS color, 
			JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."456"')) AS colorOther, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."232"')),'null','') AS countryofOrigin 
		FROM core_animal
		LEFT JOIN core_animal_herd herd 
		ON core_animal.herd_id = herd.id
		WHERE core_animal.org_id = _org_id
		AND core_animal.id NOT IN (SELECT animal_id FROM core_animal_event WHERE event_type = 9);
    ELSE 
		SELECT 
			core_animal.id as animal_id,
			core_animal.name as animal_name,
			core_animal.herd_id,
			herd.name as herd_name,
			core_animal.org_id,
			core_animal.sex as sex_id,
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 3) AND (list.value = core_animal.sex))) AS sex,              
			core_animal.tag_id,
			core_animal.farm_id,
			core_animal.sire_type as sire_type_id,
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 13) AND (list.value = core_animal.sire_type))) AS sire_type,              
			core_animal.sire_id,
			core_animal.sire_tag_id,
			core_animal.dam_id,
			core_animal.dam_tag_id,
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."91"')),'null','') AS aproximateage, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."225"')),'null','') AS animalGrade, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."226"')),'null','') AS notes, 
			core_animal.animal_photo AS animalPhoto, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."57"')),'null','') AS tagPrefix, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."58"')),'null','') AS tagSequence, 
			ifnull(core_animal.animal_type,0) AS animal_type_id,
			ifnull((SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 62) AND (list.value = core_animal.animal_type))),'Uncategorized') AS animalType, 
			DATE_FORMAT(core_animal.reg_date, '%Y-%m-%d') as registration_date, 
			DATE_FORMAT(core_animal.birthdate, '%Y-%m-%d') as dateofBirth,      
			core_animal.main_breed AS main_breed_id,
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 8) AND (list.value = core_animal.main_breed))) AS main_breed, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."147"')),'null','') AS breedCombination, 
			core_animal.breed_composition AS breedComposition_id, 
			(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 14) AND (list.value = core_animal.breed_composition))) AS breedComposition, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."223"')),'null','') AS breedCompositiondetails, 
			JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."254"')) AS color, 
			JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."456"')) AS colorOther, 
			replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."232"')),'null','') AS countryofOrigin 
		FROM core_animal
		LEFT JOIN core_animal_herd herd 
		ON core_animal.herd_id = herd.id
		WHERE core_animal.org_id = _org_id
		AND core_animal.id  IN (SELECT animal_id FROM core_animal_event WHERE event_type = 9);    
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_animal_overview_statistics_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_animal_overview_statistics_view`(_org_id integer)
BEGIN
	 SELECT `core_animal`.`org_id` AS `org_id`,
		ifnull(`core_animal`.`animal_type`,0) AS `animal_type_id`,
		ifnull((SELECT `list`.`label` FROM `core_master_list` `list` WHERE ((`list`.`list_type_id` = 62) AND (`list`.`value` = `core_animal`.`animal_type`))),'Uncategorized') AS `animal_type`,
		count(`core_animal`.`tag_id`) AS `count`, 
        (round((COUNT( `core_animal`.`tag_id` ) / ( SELECT COUNT( * ) FROM `core_animal` WHERE `core_animal`.`org_id` = _org_id AND `core_animal`.`id` not in (SELECT animal_id FROM core_animal_event WHERE event_type = 9) )) * 100 ,0)) AS percentage	
    FROM `core_animal` 
	WHERE `core_animal`.`org_id` = _org_id
    AND `core_animal`.`id` not in (SELECT animal_id FROM core_animal_event WHERE event_type = 9)
	GROUP BY `core_animal`.`org_id`,`core_animal`.`animal_type`;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_animal_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_animal_view`(_animal_id integer)
BEGIN
SELECT 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."94"')),'null',null) AS altitude, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."91"')),'null',null) AS aproximate_age, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."229"')),'null',null) AS exit_code, 
        DATE_FORMAT(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."228"')),'null',null),'%Y-%m-%d') AS exit_date, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."225"')),'null',null) AS animal_grade, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."226"')) AS notes, 
        core_animal.animal_photo AS animal_photo, 
		core_animal.herd_id AS herd_id, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."57"')) AS tag_prefix, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."58"')) AS tag_sequence, 
        core_animal.animal_type AS animal_type, 
        DATE_FORMAT(core_animal.birthdate,'%Y-%m-%d') AS date_of_birth, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."147"')),'null',null) AS breed_combination, 
        core_animal.breed_composition AS breed_composition, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."223"')) AS breed_composition_details, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."254"')) AS color, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."456"')) AS color_other, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."232"')) AS country_of_origin, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."227"')),'null',null) AS cow_status, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."249"')) AS deformaties, 
		DATE_FORMAT(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."253"')),'%Y-%m-%d') AS entry_date, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."252"')) AS entry_type, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."95"')),'null',null) AS gps_accuracy, 
        core_animal.hair_sample_id AS hair_sample_id, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."224"')) AS herd_book_number,
        core_animal.id AS animal_id,
        DATE_FORMAT(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."250"')),'null',null),'%Y-%m-%d') AS is_derived_birth_date,
        core_animal.latitude AS latitude,
        core_animal.longitude AS longitude,
        core_animal.main_breed AS main_breed,
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."457"')) AS main_breed_other,
        core_animal.name AS animal_name,       
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."251"')) AS purchase_cost,
        DATE_FORMAT(core_animal.reg_date,'%Y-%m-%d') AS registration_date,
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."458"')) AS secondary_breed, 
        JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."459"')) AS secondary_breed_other, 
        core_animal.sex AS sex,
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."231"')),'null',null) AS short_name,
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."463"')),'null',null) AS sire_owner,
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."466"')),'null',null) AS sire_owner_farmer_name,
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."467"')),'null',null) AS sire_owner_farmer_mobile_number,
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."465"')),'null',null) AS sire_owner_research_institute_name,
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal.additional_attributes, '$."464"')),'null',null) AS sire_owner_bull_scheme_name,
        core_animal.tag_id AS tag_id,
        core_animal.sire_type,
        core_animal.sire_id,
        core_animal.sire_tag_id,
        core_animal.dam_id,
        core_animal.dam_tag_id,
        auth_users.name as created_by,
        core_animal.created_at,
		updated.name updated_by,
		core_animal.updated_at,
		core_animal.migration_id,
        core_animal.odk_form_uuid       
        FROM core_animal
        left join  auth_users on core_animal.created_by = auth_users.id
        left join  auth_users  updated on core_animal.updated_by = updated.id
        WHERE core_animal.id = _animal_id ; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_authenticate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_authenticate`(_username VARCHAR(100),_password VARCHAR(100))
BEGIN	
	SELECT id,name,username,email,status,role,level,region,district,ward,village,profile_image,org_id,organization,client 
    FROM
    (SELECT 
        `users`.`id` AS `id`,
        `users`.`name` AS `name`,
        `users`.`username` AS `username`,
        `users`.`phone` AS `phone`,
        `users`.`email` AS `email`,
        `users`.`status` AS `status`,
        `users`.`timezone` AS `timezone`,
        `users`.`country_id` AS `country_id`,
        `roles`.`name` AS `role`,
        `levels`.`name` AS `level`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`region_id`) AS `region`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`district_id`) AS `district`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`ward_id`) AS `ward`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`village_id`) AS `village`,
       `users`.`profile_image` AS `profile_image`,
        `users`.`org_id` AS `org_id`,
        `organization`.`name` AS `organization`,
        `client`.`name` AS `client`,
        `users`.`password_hash` AS `password_hash`,
        `users`.`auth_key` AS `auth_key`
    FROM
        `auth_users` `users`
        LEFT JOIN `auth_roles` `roles` ON `users`.`role_id` = `roles`.`id`
        LEFT JOIN `auth_user_levels` `levels` ON `users`.`level_id` = `levels`.`id`
        LEFT JOIN `core_organization` `organization` ON `users`.`org_id` = `organization`.`id`
        LEFT JOIN `core_client` `client` ON `users`.`client_id` = `client`.`id`) as user_profiles
    WHERE (username = _username OR email = _username) AND (username = _password OR email = _password) ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_background_processes_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_background_processes_view`(_org_id integer)
BEGIN
	IF EXISTS(SELECT id FROM interface_background_processes WHERE  org_id = _org_id) 
THEN 
	SELECT 
	 a.id,
	 a.process_id,
	 a.org_id,
	 a.status_id,
     CASE WHEN a.status_id = 0 THEN 'INACTIVE'         
         ELSE 'ACTIVE' END AS status_name, 
	 b.name,
	 b.description,
	 DATE_FORMAT(replace(a.created_at,'null',''),'%Y-%m-%d') AS created_at,
	 DATE_FORMAT(replace(a.updated_at,'null',''),'%Y-%m-%d') AS updated_at,
	 auth_users.name as created_by, 
	 updated.name  updated_by
	FROM interface_background_processes  a
	LEFT JOIN interface_process_types b ON a.process_id = b.id
	LEFT JOIN auth_users ON a.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON a.updated_by = updated.id 
	WHERE  a.org_id = _org_id;
ELSE 
	SELECT 
	 a.id,
	 a.process_id,
	 a.org_id,
	 a.status_id,
     CASE WHEN a.status_id = 0 THEN 'INACTIVE'         
         ELSE 'ACTIVE' END AS status_name,  
	 b.name,
	 b.description,
	 DATE_FORMAT(replace(a.created_at,'null',''),'%Y-%m-%d') AS created_at,
	 DATE_FORMAT(replace(a.updated_at,'null',''),'%Y-%m-%d') AS updated_at,
	 auth_users.name as created_by, 
	 updated.name  updated_by
	FROM interface_background_processes  a
	LEFT JOIN interface_process_types b ON a.process_id = b.id
	LEFT JOIN auth_users ON a.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON a.updated_by = updated.id 
	WHERE  a.org_id = 0 or a.org_id is null;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_background_process_record_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_background_process_record_update`(_id integer,_status_id integer,_process_id integer,_org_id integer, _user integer )
BEGIN	
	IF EXISTS(SELECT * FROM interface_background_processes WHERE process_id  =  _process_id AND org_id = _org_id) 
    THEN
		UPDATE interface_background_processes SET status_id = _status_id, updated_at =now(), updated_by = _user WHERE id = _id;
    ELSE
        INSERT INTO interface_background_processes(process_id,org_id,status_id,created_by,created_at)      
        VALUES(_process_id,_org_id,_status_id,_user,now());
	END IF;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_background_process_record_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_background_process_record_view`(_id integer)
BEGIN	
	SELECT 
	 a.id,
	 a.process_id,
	 a.org_id,
	 a.status_id,
     CASE WHEN a.status_id = 0 THEN 'INACTIVE'         
         ELSE 'ACTIVE' END AS status_name, 
	 b.name,
	 b.description,
	 DATE_FORMAT(replace(a.created_at,'null',''),'%Y-%m-%d') AS created_at,
	 DATE_FORMAT(replace(a.updated_at,'null',''),'%Y-%m-%d') AS updated_at,
	 auth_users.name as created_by, 
	 updated.name  updated_by
	FROM interface_background_processes  a
	LEFT JOIN interface_process_types b ON a.process_id = b.id
	LEFT JOIN auth_users ON a.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON a.updated_by = updated.id 
	WHERE  a.id = _id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_batch_process_milking_action` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_batch_process_milking_action`(_uuid varchar(250),_action integer,_user integer )
BEGIN 
/*  
	Actions    
	1. validate batch
	2. Discard
	3. send records to posting queue - validation was successful 
*/
	IF  _action = 1 THEN		
        CALL sp_validate_batch_records_milking(_uuid,_user);
	END IF;	
    
    IF  _action = 2 THEN		
        CALL sp_discard_batch_records_milking(_uuid,_user);
	END IF;	
    
    IF  _action = 3 THEN		
        CALL sp_send_to_posting_queue_batch_records_milking(_uuid);
	END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_batch_process_milking_view_deleted_records` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_batch_process_milking_view_deleted_records`(_org_id integer,_user_id integer)
BEGIN  
DECLARE view_settings integer DEFAULT 0;
SET view_settings = ifnull((SELECT value FROM interface_local_settings WHERE NAME = 'MILK_BATCH_PENDING_VIEW_ALL' AND org_id = _org_id AND is_active = 1  LIMIT 1),0);
       
IF view_settings = 0 THEN  
	SELECT 
	batch.uuid,
	(SELECT count(id)  FROM  interface_batch_upload_details details WHERE (details.uuid = batch.uuid) ) AS record_count, 
    batch.id,
    batch_types.name as batch_type,
    batch.org_id,
    batch_stages.name as step,
    batch_status.name as status,   
    DATE_FORMAT(batch.created_at,'%Y-%m-%d') as created_at,  
    DATE_FORMAT(batch.created_at,'%H:%i:%s') as created_time, 
    batch.updated_at,   
    ifnull(auth_users.name,'') as created_by  
	FROM interface_batch_uploads batch
	LEFT JOIN auth_users ON batch.created_by = auth_users.id
	LEFT JOIN  interface_batch_types batch_types  on  batch.batch_type = batch_types.id
	LEFT JOIN  interface_batch_stages batch_stages  on  batch.step = batch_stages.id
	LEFT JOIN  interface_batch_status batch_status  on  batch.status = batch_status.id
	WHERE batch.org_id = _org_id and 
    batch.status =4;
    	
ELSE
	SELECT 
	batch.uuid,
    (SELECT count(id) FROM  interface_batch_upload_details details WHERE (details.uuid = batch.uuid) ) AS record_count, 
    batch.id,
    batch_types.name as batch_type,
    batch.org_id,
    batch_stages.name as step,
    batch_status.name as status,   
    DATE_FORMAT(batch.created_at,'%Y-%m-%d') as created_at,
	DATE_FORMAT(batch.created_at,'%H:%i:%s') as created_time, 
    batch.updated_at,   
    ifnull(auth_users.name,'') as created_by  
	FROM interface_batch_uploads batch
	LEFT JOIN auth_users ON batch.created_by = auth_users.id
	LEFT JOIN  interface_batch_types batch_types  on  batch.batch_type = batch_types.id
	LEFT JOIN  interface_batch_stages batch_stages  on  batch.step = batch_stages.step
	LEFT JOIN  interface_batch_status batch_status  on  batch.status = batch_status.id
	-- WHERE batch.org_id = _org_id and batch.step = _stage	
    WHERE batch.org_id = _org_id 
    -- and batch.step = _stage
    and batch.status =4
	and batch.created_by = _user_id;
END IF;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_batch_process_milking_view_records` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_batch_process_milking_view_records`(_org_id integer,_stage integer,_user_id integer)
BEGIN  
DECLARE view_settings integer DEFAULT 0;
SET view_settings = ifnull((SELECT value FROM interface_local_settings WHERE NAME = 'MILK_BATCH_PENDING_VIEW_ALL' AND org_id = _org_id AND is_active = 1  LIMIT 1),0);
       
IF view_settings = 0 THEN  
	SELECT 
	batch.uuid,
	(SELECT count(id)  FROM  interface_batch_upload_details details WHERE (details.uuid = batch.uuid) ) AS record_count, 
    batch.id,
    batch_types.name as batch_type,
    batch.org_id,
    batch_stages.name as step,
    batch_status.name as status,   
    DATE_FORMAT(batch.created_at,'%Y-%m-%d') as created_at,  
    DATE_FORMAT(batch.created_at,'%H:%i:%s') as created_time, 
    batch.updated_at,   
    ifnull(auth_users.name,'') as created_by  
	FROM interface_batch_uploads batch
	LEFT JOIN auth_users ON batch.created_by = auth_users.id
	LEFT JOIN  interface_batch_types batch_types  on  batch.batch_type = batch_types.id
	LEFT JOIN  interface_batch_stages batch_stages  on  batch.step = batch_stages.id
	LEFT JOIN  interface_batch_status batch_status  on  batch.status = batch_status.id
	WHERE batch.org_id = _org_id  
    AND batch.status in (1,2,3)
    AND batch.step in (1,2);
    -- batch.step = _stage;	
ELSE
	SELECT 
	batch.uuid,
    (SELECT count(id) FROM  interface_batch_upload_details details WHERE (details.uuid = batch.uuid) ) AS record_count, 
    batch.id,
    batch_types.name as batch_type,
    batch.org_id,
    batch_stages.name as step,
    batch_status.name as status,   
    DATE_FORMAT(batch.created_at,'%Y-%m-%d') as created_at,
	DATE_FORMAT(batch.created_at,'%H:%i:%s') as created_time, 
    batch.updated_at,   
    ifnull(auth_users.name,'') as created_by  
	FROM interface_batch_uploads batch
	LEFT JOIN auth_users ON batch.created_by = auth_users.id
	LEFT JOIN  interface_batch_types batch_types  on  batch.batch_type = batch_types.id
	LEFT JOIN  interface_batch_stages batch_stages  on  batch.step = batch_stages.step
	LEFT JOIN  interface_batch_status batch_status  on  batch.status = batch_status.id
	-- WHERE batch.org_id = _org_id and batch.step = _stage	
    WHERE batch.org_id = _org_id 
    -- and batch.step = _stage
    and batch.step in (1,2)	
	and batch.status in (1,2,3)
	and batch.created_by = _user_id;
END IF;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_batch_process_milking_view_record_error` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_batch_process_milking_view_record_error`(_id integer)
BEGIN 
	SET @erro_ids = (SELECT SUBSTR(trim(notes),2)  FROM interface_batch_upload_details WHERE id = _id);   
	SELECT error_check,error_condition 
    FROM interface_batch_validation_errors
    WHERE FIND_IN_SET(id,@erro_ids);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_cob_graduation_create_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cob_graduation_create_list`()
BEGIN
	DECLARE finished INTEGER DEFAULT 0;
	DECLARE org integer DEFAULT 0;

	/*declare cursor for organization/farm/units*/
	DEClARE curOrg 
		CURSOR FOR 			
            SELECT id  FROM core_organization;
	/*declare NOT FOUND handler*/
	DECLARE CONTINUE HANDLER 
        FOR NOT FOUND SET finished = 1;
	
    OPEN curOrg;
	getOrg: LOOP
		FETCH curOrg INTO org;
		IF finished = 1 THEN 
			LEAVE getOrg;
		END IF;
		/* create org graduation list*/	
        CALL sp_graduation_list_create(org);        
	END LOOP getOrg;
	CLOSE curOrg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_animal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_animal`(
_created_by integer,_animal_type integer,_birthdate date,_name varchar(100),_breed_composition integer,_hair_sample_id integer,_main_breed integer,_reg_date date,_sex integer,_tag_id varchar(100),
_breed_combination varchar(100),_notes varchar(100),_tag_prefix varchar(100),_tag_sequence varchar(100),_breed_composition_details varchar(100),_color integer,_color_other varchar(100),_country_of_origin varchar(100),
_deformities integer,_entry_date date,_entry_type integer,_herd_book_number varchar(100),_main_breed_other varchar(100),_purchase_cost decimal(17,2),_secondary_breed integer,_secondary_breed_other varchar(100),
_sire_type integer,_sire_id integer, _dam_id integer,_herd_id integer, _org_id integer,_farm_id integer
)
BEGIN 

	SET @dam_tag = (SELECT ifnull(dam_tag_id,'') from core_animal where dam_id = _dam_id LIMIT 1);
    SET @sire_tag = (SELECT ifnull(sire_tag_id,'') from core_animal where sire_id = _sire_id LIMIT 1);
    SET @additional_attributes = JSON_MERGE_PRESERVE( 
		JSON_OBJECT('147', ifnull( _breed_combination,'')), 
		JSON_OBJECT('226', ifnull( _notes,'')),
		JSON_OBJECT('57', ifnull( _tag_prefix,'')),  
		JSON_OBJECT('58', ifnull( _tag_sequence,'')),
		JSON_OBJECT('223', ifnull( _breed_composition_details,'')),
		JSON_OBJECT('254', ifnull( _color,0)),
		JSON_OBJECT('456', ifnull( _color_other,'')),
		JSON_OBJECT('232', ifnull( _country_of_origin,'')),
		JSON_OBJECT('249', ifnull( _deformities,0)),
		JSON_OBJECT('253', ifnull( _entry_date,'')), 
		JSON_OBJECT('252', ifnull( _entry_type,0)), 
		JSON_OBJECT('224', ifnull( _herd_book_number,'')), 
		JSON_OBJECT('457', ifnull( _main_breed_other,'')), 
		JSON_OBJECT('251', ifnull( _purchase_cost,0)), 
		JSON_OBJECT('458', ifnull( _secondary_breed,0)), 
		JSON_OBJECT('459', ifnull( _secondary_breed_other,'')), 
		JSON_OBJECT('231', '')
	); 
     INSERT INTO core_animal (animal_type,birthdate,name,breed_composition,hair_sample_id,main_breed,reg_date,sex,tag_id,additional_attributes,uuid,created_at,created_by,country_id,sire_type,sire_id,sire_tag_id,dam_id,dam_tag_id,herd_id,org_id,farm_id)
     VALUES(_animal_type,_birthdate,_name,_breed_composition,_hair_sample_id,_main_breed,_reg_date,_sex,_tag_id,@additional_attributes,UUID(),curdate(),_created_by,0,_sire_type,_sire_id,@sire_tag_id,_dam_id,@dam_tag_id,_herd_id,_org_id,_farm_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_batch_upload_milk` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_batch_upload_milk`(_batch_type integer,_row_attributes json,_column_attributes json,_org_id integer,_created_by integer,_uuid varchar(250),_rows_table text)
BEGIN
	INSERT INTO interface_batch_uploads(batch_type,row_attributes,column_attributes,org_id,created_at,created_by,step,uuid,status)
	VALUES(_batch_type,_row_attributes,_column_attributes,_org_id,now(),_created_by,1,_uuid,1);
	SET @sql_str = CONCAT('INSERT INTO interface_batch_upload_details(milk_date,animal_id,amount_morning,amount_noon,amount_afternoon,uuid)values',_rows_table);
	PREPARE stmt1 FROM @sql_str;
	EXECUTE stmt1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_calender_events` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_calender_events`(_title varchar(100),_description varchar(200),_event_start_datetime datetime,_event_end_datetime datetime,_all_day tinyint,_color int,_org_id int,_created_by int)
BEGIN 
	insert into interface_calender_events 
   (title,description,event_start_datetime,event_end_datetime,all_day,color,uuid,org_id,created_at,created_by)
    values(_title,_description,_event_start_datetime,_event_end_datetime,_all_day,_color,uuid(),_org_id,now(),_created_by); 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_calving` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_calving`(
_animal_id integer,_calving_date date,_birth_type integer,_body_condition_score integer,_calf_color integer,_calf_deformities integer,_other_calf_deformities varchar(100), _heart_girth decimal(10,2),_calf_name varchar(100), _calf_sex integer,_calf_weight decimal(10,2),
_ease_of_calving_other varchar(100), _calving_method integer,_calving_type_other varchar(100),_calving_type integer,_ease_of_calving integer,_calving_status integer,_use_of_calf integer,_use_of_calf_other varchar(100),_calf_tag_id varchar(100),
_lactation_number varchar(100),_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 1;  

    SET @additional_attributes = JSON_MERGE_PRESERVE(    
		JSON_OBJECT('71', ifnull( _birth_type,0)),        
        JSON_OBJECT('80', ifnull(_body_condition_score,'')),
        JSON_OBJECT('88', ifnull(_calf_color,'')),
        JSON_OBJECT('77', ifnull(_calf_deformities,'')),
        JSON_OBJECT('98', ifnull(_other_calf_deformities,'')), 
        JSON_OBJECT('79', ifnull(_heart_girth,0)),
        JSON_OBJECT('84', ifnull(_calf_name,0)), 
        JSON_OBJECT('73', ifnull(_calf_sex,'')),
        JSON_OBJECT('78', ifnull(_calf_weight,'')),
        JSON_OBJECT('461', ifnull(_ease_of_calving_other,0)), 
        JSON_OBJECT('233', ifnull(_calving_method,0)),
        JSON_OBJECT('460', ifnull(_calving_type_other,0)),
        JSON_OBJECT('69', ifnull(_calving_type,0)),
        JSON_OBJECT('70', ifnull(_ease_of_calving,0)),
        JSON_OBJECT('72', ifnull(_calving_status,0)),
        JSON_OBJECT('81', ifnull(_use_of_calf,0)),
        JSON_OBJECT('97', ifnull(_use_of_calf_other,0)),        
        JSON_OBJECT('87', ifnull(_calf_tag_id,0))       
	);  
     INSERT INTO core_animal_event (animal_id,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id,lactation_number)
     VALUES(_animal_id,@event_id,CURDATE(),ifnull(_calving_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id,_lactation_number);
     
     CALL sp_create_animal(_created_by, 3, _calving_date, _calf_name, null, null, null, _calving_date,_calf_sex,
     _calf_tag_id,"", "", "", "", "",_calf_color, "", "", _calf_deformities, _calving_date,
     5, '', '', 0, null, '', null, null, _animal_id, null, 5, null);



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_exits` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_exits`(
_animal_id integer,exit_date date,_disposal_amount decimal(17,2),_disposal_reason integer,_disposal_reason_other varchar(100),_new_breeder_name varchar(100),_new_breeder_phone_number varchar(100),
_new_country integer,_new_district integer,_new_farmer_name varchar(100) ,_new_farmer_phone_number varchar(100),_new_region integer,_new_village integer,
_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 9;  
    SET @additional_attributes = JSON_MERGE_PRESERVE( 
    
		JSON_OBJECT('245', ifnull( _disposal_amount,0)),
        JSON_OBJECT('247', ifnull( _disposal_reason,'')),
		JSON_OBJECT('246', ifnull( _disposal_reason_other,'')),
        JSON_OBJECT('237', ifnull( _new_breeder_name,'')),
        JSON_OBJECT('236', ifnull( _new_breeder_phone_number,'')),       
        JSON_OBJECT('244', ifnull( _new_country,0)),
        JSON_OBJECT('242', ifnull( _new_district,0)),        
		JSON_OBJECT('238', ifnull( _new_farmer_name,'')),
		JSON_OBJECT('239', ifnull( _new_farmer_phone_number,'')),
        JSON_OBJECT('243', ifnull( _new_region,0)),        
        JSON_OBJECT('240', ifnull( _new_village,0))
	);  
     INSERT INTO core_animal_event (animal_id,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id)
     VALUES(_animal_id,@event_id,CURDATE(),ifnull(exit_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_health` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_health`(
_animal_id integer,_health_date date,_health_category varchar(100),_drug_cost decimal(17,2),_health_provider integer,_health_type integer,_other_health_type varchar(100),_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 7;  
    SET @additional_attributes = JSON_MERGE_PRESERVE(
		JSON_OBJECT('141', ifnull(_health_category,'')),
        JSON_OBJECT('145', ifnull(_drug_cost,0)),
		JSON_OBJECT('144', ifnull(_health_provider,0)),
        JSON_OBJECT('142', ifnull(_health_type,0)),
        JSON_OBJECT('143', ifnull(_other_health_type,'')) 
	);  
     INSERT INTO core_animal_event (animal_id,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id)
     VALUES(_animal_id,@event_id,CURDATE(),ifnull(_health_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_insemination` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_insemination`(
_animal_id integer,_ai_date date,_straw_semen_type integer,_type_of_ai integer,_straw_id varchar(50),_country_of_origin varchar(50),
_body_condition_score integer,_breed_composition_bull integer,_ai_cost DECIMAL(15,2),_cow_weight DECIMAL(15,2),_semen_batch varchar(100),
_semen_source integer,_semen_source_other varchar(100),_breed_of_bull integer,_breed_of_bull_other varchar(100),
_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 3;  
    SET @additional_attributes = JSON_MERGE_PRESERVE(		
        JSON_OBJECT('106', ifnull( _straw_semen_type,0)),
        JSON_OBJECT('105', ifnull( _type_of_ai,0)),
        JSON_OBJECT('107', ifnull( _straw_id,'')),
        JSON_OBJECT('110', ifnull( _country_of_origin,0)),
        JSON_OBJECT('103', ifnull( _ai_date,0)),
        
		JSON_OBJECT('104', ifnull( _body_condition_score,0)),
		JSON_OBJECT('113', ifnull( _breed_composition_bull,0)),
        JSON_OBJECT('114', ifnull( _ai_cost,0)),
        JSON_OBJECT('115', ifnull( _cow_weight,0)),
		JSON_OBJECT('116', ifnull( _semen_batch,'')),
        
        JSON_OBJECT('108', ifnull( _semen_source,0)),
        JSON_OBJECT('109', ifnull( _semen_source_other,'')),
        JSON_OBJECT('111', ifnull( _breed_of_bull,0)),
        JSON_OBJECT('112', ifnull( _breed_of_bull_other,''))
	);  
     INSERT INTO core_animal_event (animal_id,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id)
     VALUES(_animal_id,@event_id,CURDATE(),ifnull(_ai_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_milking` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_milking`(
_animal_id integer,_milk_date date,_days_in_milk integer,_lactation_id integer,_lactation_number integer,_milking_notes varchar(300)
,_milk_sample_type_id integer,_milk_pm_litres float,_milk_butter_fat float,_milk_lactose float,_milk_mid_day float,_milk_protein float,
_milk_am_litres float,_milk_somatic_cell_count bigint,_milk_urea float,_testday_no integer,_milk_Weight float,
_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 2;  
    SET @milk_composite_litres = ifnull(_milk_am_litres,0) + ifnull(_milk_mid_day,0) + ifnull(_milk_pm_litres,0);     
    SET @additional_attributes = JSON_MERGE_PRESERVE(
        JSON_OBJECT('209', _milk_Weight),
        JSON_OBJECT('67', _milk_urea),
        JSON_OBJECT('66', _milk_somatic_cell_count),
        JSON_OBJECT('59', ifnull( _milk_am_litres,0)),
        JSON_OBJECT('64',  _milk_protein),
         
		JSON_OBJECT('68', ifnull( _milk_mid_day,0)),
		JSON_OBJECT('65', _milk_lactose),
        JSON_OBJECT('63', _milk_butter_fat),
        JSON_OBJECT('61', ifnull( _milk_pm_litres,0)),
		JSON_OBJECT('62', ifnull( @milk_composite_litres,0)),
        
       JSON_OBJECT('235', ''),
        JSON_OBJECT('102', ifnull( _milk_sample_type_id,0)),       
        JSON_OBJECT('167', ifnull( _milking_notes,'')),
        JSON_OBJECT('219', ''),
        JSON_OBJECT('220', 0),
        JSON_OBJECT('218', ''),
        JSON_OBJECT('164', ''),
        JSON_OBJECT('221', ifnull( _days_in_milk,0))
	);  
     INSERT INTO core_animal_event (animal_id,testday_no,lactation_id,lactation_number,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id)
     VALUES(_animal_id,_testday_no,_lactation_id,_lactation_number,@event_id,ifnull(_milk_date,CURDATE()),ifnull(_milk_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_pd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_pd`(_animal_id integer,_service_date date,_isServiceDateKnown boolean, _time_examined time,_pd_results integer,_pd_stage integer,_body_score integer,_cost DECIMAL(10,2),_pd_method integer,_data_collection_date date,_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 4;  
    SET @additional_attributes = JSON_MERGE_PRESERVE(		
        JSON_OBJECT('128', ifnull( _isServiceDateKnown,0)),
        JSON_OBJECT('129', ifnull( _service_date,0)),
        JSON_OBJECT('130', ifnull( _time_examined,0)),
        JSON_OBJECT('131', ifnull( _pd_results,0)),
        JSON_OBJECT('132', ifnull( _pd_stage,0)),
		JSON_OBJECT('133', ifnull( _body_score,0)),
		JSON_OBJECT('134', ifnull( _cost,0)),
        JSON_OBJECT('135', ifnull( _pd_method,0))		  
	); 
    
     INSERT INTO core_animal_event (animal_id,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id)
     VALUES(_animal_id,@event_id,CURDATE(),ifnull(_data_collection_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_sync` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_sync`(
_animal_id integer,_sync_date date,_sync_number integer, _animal_parity integer,_sync_time time,_hormone_type integer,
_other_hormone_type varchar(100),_hormone_source integer,_other_hormone_source varchar(100),_sync_cost DECIMAL(10,2),
_sync_person integer,_sync_other_person varchar(100),_sync_person_phone varchar(30),
_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 5;  
    SET @additional_attributes = JSON_MERGE_PRESERVE(		
        JSON_OBJECT('117', ifnull( _sync_number,0)),
        JSON_OBJECT('118', ifnull( _animal_parity,0)),
        JSON_OBJECT('119', ifnull( _sync_time,0)),
        JSON_OBJECT('120', ifnull( _hormone_type,0)),
        JSON_OBJECT('121', ifnull( _other_hormone_type,'')),
		JSON_OBJECT('122', ifnull( _hormone_source,0)),
		JSON_OBJECT('123', ifnull( _other_hormone_source,'')),
        JSON_OBJECT('124', ifnull( _sync_cost,0)),
        JSON_OBJECT('125', ifnull( _sync_person,0)),
		JSON_OBJECT('126', ifnull( _sync_other_person,'')),
        JSON_OBJECT('127', ifnull( _sync_person_phone,0))
	); 
    
     INSERT INTO core_animal_event (animal_id,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id)
     VALUES(_animal_id,@event_id,CURDATE(),ifnull(_sync_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_event_weight` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_event_weight`(_animal_id integer,_body_length float,_heart_girth float,_weight float,_body_score integer,_data_collection_date date,_field_agent_id integer,_created_by integer)
BEGIN
	SET @country_id = (SELECT ifnull(country_id,0) from core_animal where id = _animal_id LIMIT 1);
    SET @event_id  = 6;
    SET @additional_attributes = JSON_MERGE_PRESERVE(
    JSON_OBJECT('136', ifnull( _weight,0)),
    JSON_OBJECT('137', ifnull( _heart_girth,0)),
    JSON_OBJECT('138', ifnull( _body_length,0)),
    JSON_OBJECT('139', ifnull( _body_score,0))
    );
    
 
     INSERT INTO core_animal_event (animal_id,event_type,event_date,data_collection_date,uuid,field_agent_id,
     additional_attributes,created_at,created_by,country_id)
     VALUES(_animal_id,@event_id,ifnull(_data_collection_date,CURDATE()),ifnull(_data_collection_date,CURDATE()),UUID(),_field_agent_id,@additional_attributes,CURDATE(),_created_by,@country_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_parameter_limit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_parameter_limit`(_category varchar(100),_description varchar(300),_min_value decimal(19,4),_max_value decimal(19,4),_is_active tinyint,_user int)
BEGIN
insert into interface_limit_parameters(category,description,min_value,max_value,is_active,created_at,created_by)
values(_category,_description,_min_value,_max_value,_is_active,CURDATE(),_user);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_parameter_local_settings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_parameter_local_settings`(_name VARCHAR(200),_key VARCHAR(200),_value VARCHAR(200),_is_active TINYINT,_description VARCHAR(300),_org_id integer,_farm_id integer,_created_by integer)
BEGIN
	 INSERT INTO interface_local_settings(name,`key`,value,is_active,description,org_id,farm_id,created_by,created_at)
     VALUES(_name,_key,_value,_is_active,_description,_org_id,_farm_id,_created_by,CURDATE());
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_discard_batch_records_milking` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_discard_batch_records_milking`(_uuid varchar(250),_user_id integer)
BEGIN
	UPDATE  interface_batch_uploads SET STATUS = 4, updated_at = now() , updated_by = _user_id 
    WHERE uuid = _uuid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_calving_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_calving_view`(_animal_id integer)
BEGIN 
SELECT  
	DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date, 
	DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS calving_date,
	replace(core_animal_event.field_agent_id,'null','') AS field_agent_id, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."75"')),'null','') AS `ai_provider_id`, 
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 18) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."75"'))))) AS ai_provider, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."96"')),'null','') AS `other_provider`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."71"')),'null','') AS `calving_birth_type_id`,
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 20) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."71"'))))) AS calving_birth_type, 
    replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."90"')),'null','') AS `calf_body_image`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."80"')),'null','') AS `calf_body_condition_score_id`, 
	 (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 71) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."80"'))))) AS calf_body_condition_score, 
    replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."88"')),'null','') AS `calf_color_id`, 
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 83) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."88"'))))) AS calf_color, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."77"')),'null','') AS `calf_deformities_id`, 
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 11) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."77"'))))) AS calf_deformities, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."98"')),'null','') AS `other_calf_deformities`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."79"')),'null','') AS `calf_heart_girth`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."84"')),'null','') AS `calf_name`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."73"')),'null','') AS `calf_sex_id`, 
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 3) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."73"'))))) AS calf_sex, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."74"')),'null','') AS `calf_sire_type_id`, 
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 13) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."74"'))))) AS calf_sire_type, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."89"')),'null','') AS `calf_tag_image`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."85"')),'null','') AS `calf_tag_id_prefix`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."86"')),'null','') AS `calf_tag_id_sec`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."78"')),'null','') AS `calf_weight`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."99"')),'null','') AS `calf_weight_known_id`,
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 67) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."99"'))))) AS calf_weight_known, 
      replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."461"')),'null','') AS ease_of_calving_other,
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."233"')),'null','') AS calving_method_id,
  (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 15) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."233"'))))) AS calving_method, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."460"')),'null','') AS calving_type_other, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."69"')),'null','') AS calving_type_id, 
  (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 16) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."69"'))))) AS calving_type, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."70"')),'null','') AS ease_of_calving,
  (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 19) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."70"'))))) AS ai_provider, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."72"')),'null','') AS calving_status_id,
  (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 22) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."72"'))))) AS calving_status, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."81"')),'null','') AS use_of_calf,
  (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 21) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."81"'))))) AS ai_provider, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."97"')),'null','') AS use_of_calf_other,
 replace(core_animal_event.lactation_id,'null','') AS lactation_id,
 replace(core_animal_event.lactation_number,'null','') AS lactation_number, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."87"')),'null','') AS calf_tag_id, 
    core_animal_event.id AS event_id,
	ifnull(auth_users.name,'') as created_by
FROM core_animal_event
LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID
WHERE core_animal_event.event_type = 1
AND core_animal_event.animal_id = _animal_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_exits_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_exits_view`(_animal_id integer)
BEGIN
SELECT 
	core_animal_event.id AS event_id,
    DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date, 
	DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS disposal_date,
	replace(core_animal_event.field_agent_id,'null','') AS field_agent_id,	
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."245"')),'null','') AS disposal_amount,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."247"')),'null','') AS disposal_reason_id,
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 82) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."247"'))))) AS disposal_reason, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."246"')),'null','') AS disposal_reason_other,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."237"')),'null','') AS new_breeder_name,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."236"')),'null','') AS new_breeder_phone_number, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."244"')),'null','') AS new_country,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."242"')),'null','') AS new_district,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."238"')),'null','') AS new_farmer_name,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."239"')),'null','') AS new_farmer_phone_number,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."243"')),'null','') AS new_region,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."240"')),'null','') AS new_village,
    DATE_FORMAT(ifnull(replace(core_animal_event.created_at,'null',''),''),'%Y-%m-%d') AS date_created,
	ifnull(auth_users.name,'') as created_by
    FROM core_animal_event
    LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID
	WHERE core_animal_event.event_type = 9
    AND core_animal_event.animal_id = _animal_id ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_exit_list_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_exit_list_view`(_org_id integer)
BEGIN
SELECT 
	core_animal_event.id AS event_id,
    core_animal_event.animal_id,
    core_animal.tag_id,
    core_animal.name,
    core_animal.org_id,
    DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date, 
	DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS disposal_date,
	replace(core_animal_event.field_agent_id,'null','') AS field_agent_id,	
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."245"')),'null','') AS disposal_amount,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."247"')),'null','') AS disposal_reason_id,
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 82) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."247"'))))) AS disposal_reason, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."246"')),'null','') AS disposal_reason_other,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."237"')),'null','') AS new_breeder_name,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."236"')),'null','') AS new_breeder_phone_number, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."244"')),'null','') AS new_country,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."242"')),'null','') AS new_district,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."238"')),'null','') AS new_farmer_name,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."239"')),'null','') AS new_farmer_phone_number,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."243"')),'null','') AS new_region,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."240"')),'null','') AS new_village,
    DATE_FORMAT(ifnull(replace(core_animal_event.created_at,'null',''),''),'%Y-%m-%d') AS date_created,
	ifnull(auth_users.name,'') as created_by
    FROM core_animal_event
    LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID
    LEFT JOIN core_animal ON core_animal_event.animal_id = core_animal.id    
	WHERE core_animal_event.event_type = 9
    AND core_animal.org_id = _org_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_heath_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_heath_view`(_animal_id integer)
BEGIN 
	SELECT 
		DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date, 
        DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS health_date, 
        replace(core_animal_event.field_agent_id,'null','') AS field_agent_id, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."141"')),'null','') AS health_category, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."145"')),'null','') AS drug_cost, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."144"')),'null','') AS health_provider_id,
        (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 47) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."144"'))))) AS health_provider, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."142"')),'null','') AS health_type_id, 
        (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 49) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."142"'))))) AS health_type, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."143"')),'null','') AS other_health_type, 
        core_animal_event.id AS event_id,
        ifnull(auth_users.name,'') as created_by
	FROM core_animal_event
	LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID
	WHERE core_animal_event.event_type = 7
	AND core_animal_event.animal_id = _animal_id ;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_insemination_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_insemination_view`(_animal_id integer)
BEGIN
	SELECT 
    core_animal_event.id as event_id,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."104"')),'null','') AS body_condition_score_id,
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 71) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."104"'))))) AS body_condition_score, 
     replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."113"')),'null','') AS breed_composition_of_bull_id,
	 (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 14) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."113"'))))) AS breed_composition_of_bull, 
     replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."114"')),'null','') AS ai_cost,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."115"')),'null','') AS cow_weight,
	 DATE_FORMAT(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."103"')),'null',''),'%Y-%m-%d') AS insemination_service_date, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."116"')),'null','') AS semen_batch, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."108"')),'null','') AS source_of_semen_id,
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 74) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."108"'))))) AS source_of_semen, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."109"')),'null','') AS other_source_of_semen,     
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."111"')),'null','') AS breed_of_the_bull_id, 
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 8) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."111"'))))) AS breed_of_the_bull, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."112"')),'null','') AS other_breed,    
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."110"')),'null','') AS country_of_sire_bull_origin,
     replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."107"')),'null','') AS straw_id_scan_sire_code,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."106"')),'null','') AS straw_semen_type_id,
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 73) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."106"'))))) AS straw_semen_type, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."105"')),'null','') AS type_of_ai_id,
     (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 72) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."105"'))))) AS type_of_ai, 
	 DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date,
	 DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS ai_date,
	 replace(core_animal_event.field_agent_id,'null','') AS field_agent_id 
	FROM core_animal_event 
    LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID   
    WHERE core_animal_event.event_type = 3
	AND core_animal_event.animal_id = _animal_id ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_menu_setup_all_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_menu_setup_all_view`()
BEGIN
  select 
	ifnull(cat.label,'uncategorized') animal_type,
    settings.animal_type as animal_type_id,
    settings.calving,
    settings.milking,
    settings.health,
    settings.bio_data,
    settings.insemination,
    settings.sync,
    settings.exit,
    settings.weight,
    settings.pd,
    updated.name  updated_by,
    auth_users.name as created_by,
    DATE_FORMAT(replace(settings.created_at,'null',''),'%Y-%m-%d') AS created_at,
    DATE_FORMAT(replace(settings.updated_at,'null',''),'%Y-%m-%d') AS updated_at
from interface_animal_event_menus_setup settings
left join (select * from core_master_list where list_type_id =62) cat
on settings.animal_type = cat.value
LEFT JOIN auth_users ON settings.created_by = auth_users.ID 
LEFT JOIN  auth_users updated ON settings.updated_by = updated.id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_menu_setup_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_menu_setup_view`(_animal_id integer)
BEGIN
  select 
	ifnull(cat.label,'uncategorized') animal_type,
    settings.animal_type as animal_type_id,
    settings.calving,
    settings.milking,
    settings.health,
    settings.bio_data,
    settings.insemination,
    settings.sync,
    settings.exit,
    settings.weight,
    settings.pd    
from interface_animal_event_menus_setup settings
left join (select * from core_master_list where list_type_id =62) cat
on settings.animal_type = cat.value
where settings.animal_type = (select ifnull(animal_type,0) from core_animal where id = _animal_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_milking_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_milking_view`(_animal_id integer)
BEGIN
SELECT 
  replace(core_animal_event.data_collection_date,'null','') AS data_collection_date,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."221"')),'null','') AS days_in_milk,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."164"')),'null','') AS dry_date,
  replace(core_animal_event.event_date,'null','') AS milk_date, 
  replace(core_animal_event.field_agent_id,'null','') AS field_agent_id,
  replace(core_animal_event.id,'null','') AS event_id,
  replace(core_animal_event.lactation_id,'null','') AS lactation_id, 
  replace(core_animal_event.lactation_number,'null','') AS lactation_number,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."218"')),'null','') AS body_score_id, 
  (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 71) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."218"'))))) AS body_score,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."220"')),'null','') AS estimated_weight,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."219"')),'null','') AS heart_girth,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."167"')),'null','') AS milking_notes, 
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."166"')),'null','') AS milk_quality,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."102"')),'null','') AS milk_sample_type_id,
 (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 70) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."102"'))))) AS milk_sample_type, 
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."235"')),'null','') AS test_type,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."62"')),'null','') AS milk_composite_litres,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."61"')),'null','') AS milk_pm_litres,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."63"')),'null','') AS milk_butter_fat,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."65"')),'null','') AS milk_lactose,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."68"')),'null','') AS milk_mid_day,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."64"')),'null','') AS milk_protein,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."59"')),'null','') AS milk_am_litres,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."66"')),'null','') AS milk_somatic_cell_count, 
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."67"')),'null','') AS milk_urea,
  replace(core_animal_event.testday_no,'null','') AS testday_no,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."209"')),'null','') AS milk_Weight,
 ifnull(auth_users.name,'') as created_by
 FROM core_animal_event 
 LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
 WHERE (core_animal_event.event_type = 2)
AND core_animal_event.animal_id = _animal_id 
ORDER BY core_animal_event.event_date DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_pd_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_pd_view`(_animal_id integer)
BEGIN
	SELECT
    core_animal_event.id as event_id,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."131"')),'null','') AS pd_result_id,
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 78) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."131"'))))) AS pd_result, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."128"')),'null','') AS is_service_date_known, 
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 67) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."128"'))))) AS yes_no, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."133"')),'null','') AS body_condition_score_id, 
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 71) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."133"'))))) AS body_condition_score, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."134"')),'null','') AS cost, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."130"')),'null','') AS time_examined, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."135"')),'null','') AS pd_method_id,
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 80) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."135"'))))) AS pd_method,  
	DATE_FORMAT(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."129"')),'null',''),'%Y-%m-%d') AS service_date, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."132"')),'null','') AS pd_stage_id, 
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 79) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."132"'))))) AS pd_stage, 
	DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_Date, 
	DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS examination_date, 
	ifnull(replace(core_animal_event.field_agent_id,'null',''),'') AS field_agent, 
	DATE_FORMAT(ifnull(replace(core_animal_event.created_at,'null',''),''),'%Y-%m-%d') AS date_created,
	ifnull(auth_users.name,'') as created_by
	FROM core_animal_event
	LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID
	WHERE core_animal_event.event_type = 4
	AND core_animal_event.animal_id = _animal_id ;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_record_insemination_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_record_insemination_view`(_event_id integer)
BEGIN
	SELECT 
    core_animal_event.id as event_id,
    core_animal_event.animal_id as animal_id, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."104"')),'null','') AS body_condition_score,
     replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."113"')),'null','') AS breed_composition,
     replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."114"')),'null','') AS cost,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."115"')),'null','') AS cow_weight,
	 DATE_FORMAT(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."103"')),'null',''),'%Y-%m-%d') AS insemination_service_date, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."116"')),'null','') AS semen_batch, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."108"')),'null','') AS source_of_semen,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."109"')),'null','') AS other_Semen_source,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."111"')),'null','') AS breed_of_bull, 
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."112"')),'null','') AS other_breed_of_bull,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."110"')),'null','') AS origin_country_bull,
     replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."107"')),'null','') AS straw_id,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."106"')),'null','') AS straw_semen_type,
	 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."105"')),'null','') AS ai_type,
	 DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date,
	 DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS service_date,
	 replace(core_animal_event.field_agent_id,'null','') AS field_agent_id, 
	auth_users.name as created_by,
		core_animal_event.migration_id,
		core_animal_event.odk_form_uuid,		
		DATE_FORMAT(replace(core_animal_event.created_at,'null',''),'%Y-%m-%d') AS created_at,
        DATE_FORMAT(replace(core_animal_event.updated_at,'null',''),'%Y-%m-%d') AS updated_at, 
		updated.name  updated_by
     FROM core_animal_event 
     LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
     LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id       
	 WHERE core_animal_event.id = _event_id ;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_record_milking_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_record_milking_view`(_event_id integer)
BEGIN
SELECT 
  core_animal_event.animal_id as animal_id, 
  replace(core_animal_event.data_collection_date,'null','') AS data_collection_date,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."221"')),'null','') AS days_in_milk,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."164"')),'null','') AS dry_date,
  replace(core_animal_event.event_date,'null','') AS milk_date, 
  replace(core_animal_event.field_agent_id,'null','') AS field_agent_id,
  replace(core_animal_event.id,'null','') AS event_id,
  replace(core_animal_event.lactation_id,'null','') AS lactation_id, 
  replace(core_animal_event.lactation_number,'null','') AS lactation_number,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."218"')),'null','') AS body_score_id, 
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."220"')),'null','') AS estimated_weight,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."219"')),'null','') AS heart_girth,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."167"')),'null','') AS milking_notes, 
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."166"')),'null','') AS milk_quality,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."102"')),'null','') AS milk_sample_type,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."235"')),'null','') AS test_type,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."62"')),'null','') AS milk_composite_litres,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."61"')),'null','') AS milk_pm_litres,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."63"')),'null','') AS milk_butter_fat,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."65"')),'null','') AS milk_lactose,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."68"')),'null','') AS milk_mid_day,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."64"')),'null','') AS milk_protein,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."59"')),'null','') AS milk_am_litres,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."66"')),'null','') AS milk_somatic_cell_count, 
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."67"')),'null','') AS milk_urea,
  replace(core_animal_event.testday_no,'null','') AS testday_no,
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."209"')),'null','') AS milk_Weight,
  core_animal_event.id AS event_id, 
	auth_users.name as created_by,
	core_animal_event.migration_id,
	core_animal_event.odk_form_uuid,		
	DATE_FORMAT(replace(core_animal_event.created_at,'null',''),'%Y-%m-%d') AS created_at,
	DATE_FORMAT(replace(core_animal_event.updated_at,'null',''),'%Y-%m-%d') AS updated_at, 
	updated.name  updated_by
 FROM core_animal_event 
 LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
 LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id       
 WHERE core_animal_event.id = _event_id ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_record_view_exit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_record_view_exit`(_event_id integer)
BEGIN
	 SELECT 
		core_animal_event.animal_id as animal_id, 
        core_animal.tag_id,
        core_animal.name,
		core_animal_event.id as event_id, 
		DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date, 
		DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS exit_date,
		replace(core_animal_event.field_agent_id,'null','') AS field_agent_id,	
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."245"')),'null','') AS disposal_amount,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."247"')),'null','') AS disposal_reason,	
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."246"')),'null','') AS disposal_reason_other,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."237"')),'null','') AS new_breeder_name,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."236"')),'null','') AS new_breeder_phone_no, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."244"')),'null','') AS new_country,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."242"')),'null','') AS new_district,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."238"')),'null','') AS new_farmer_name,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."239"')),'null','') AS new_farmer_phone_no,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."243"')),'null','') AS new_region,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."240"')),'null','') AS new_village,		
		ifnull(auth_users.name,'') as created_by,    
		auth_users.name as created_by,
		core_animal_event.migration_id,
		core_animal_event.odk_form_uuid,		
		DATE_FORMAT(replace(core_animal_event.created_at,'null',''),'%Y-%m-%d') AS created_at,
        DATE_FORMAT(replace(core_animal_event.updated_at,'null',''),'%Y-%m-%d') AS updated_at, 
		updated.name  updated_by
     FROM core_animal_event 
     LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
     LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id 
     LEFT JOIN core_animal ON core_animal_event.animal_id = core_animal.id 
	 WHERE core_animal_event.id = _event_id ;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_record_view_health` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_record_view_health`(_event_id integer)
BEGIN
	 SELECT 
		core_animal_event.animal_id as animal_id, 
		DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date, 
        DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS health_date, 
        replace(core_animal_event.field_agent_id,'null','') AS field_agent_id, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."141"')),'null','') AS health_category, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."145"')),'null','') AS drug_cost, 
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."144"')),'null','') AS health_provider,        
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."142"')),'null','') AS health_type,
        replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."143"')),'null','') AS other_health_type, 
        core_animal_event.id AS event_id, 
		auth_users.name as created_by,
		core_animal_event.migration_id,
		core_animal_event.odk_form_uuid,		
		DATE_FORMAT(replace(core_animal_event.created_at,'null',''),'%Y-%m-%d') AS created_at,
        DATE_FORMAT(replace(core_animal_event.updated_at,'null',''),'%Y-%m-%d') AS updated_at, 
		updated.name  updated_by
     FROM core_animal_event 
     LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
     LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id       
	 WHERE core_animal_event.id = _event_id ;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_record_view_sync` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_record_view_sync`(_event_id integer)
BEGIN
	 SELECT 
		core_animal_event.animal_id as animal_id, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."120"')),'null','') AS hormone_type,		
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."117"')),'null','') AS sync_number, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."122"')),'null','') AS hormone_source, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."125"')),'null','') AS sync_person,
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."124"')),'null','') AS cost, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."121"')),'null','') AS other_hormone_type, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."118"')),'null','') AS animal_parity, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."123"')),'null','') AS other_hormone_source, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."119"')),'null','') AS sync_time, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."126"')),'null','') AS sync_other_person, 
		replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."127"')),'null','') AS sync_person_phone, 
		DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS sync_date, 
		DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS event_date, 
		ifnull(replace(core_animal_event.field_agent_id,'null',''),'') AS field_agent_id, 
		core_animal_event.id AS event_id,	 
		auth_users.name as created_by,
		core_animal_event.migration_id,
		core_animal_event.odk_form_uuid,		
		DATE_FORMAT(replace(core_animal_event.created_at,'null',''),'%Y-%m-%d') AS created_at,
        DATE_FORMAT(replace(core_animal_event.updated_at,'null',''),'%Y-%m-%d') AS updated_at, 
		updated.name  updated_by
     FROM core_animal_event 
     LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
     LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id       
	 WHERE core_animal_event.id = _event_id ;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_specific_calving_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_specific_calving_view`(_event_id integer)
BEGIN 
SELECT 
	core_animal_event.animal_id as animal_id, 
	DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS data_collection_date, 
	DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS calving_date,
	replace(core_animal_event.field_agent_id,'null','') AS field_agent_id, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."75"')),'null','') AS `ai_provider`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."96"')),'null','') AS `other_provider`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."71"')),'null','') AS `calving_birth_type`,
    replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."90"')),'null','') AS `calf_body_image`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."80"')),'null','') AS `calf_body_condition_score`, 
    replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."88"')),'null','') AS `calf_color`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."77"')),'null','') AS `calf_deformities`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."98"')),'null','') AS `other_calf_deformities`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."79"')),'null','') AS `calf_heart_girth`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."84"')),'null','') AS `calf_name`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."73"')),'null','') AS calf_gender, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."74"')),'null','') AS `calf_sire_type`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."89"')),'null','') AS `calf_tag_image`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."85"')),'null','') AS `calf_tag_id_prefix`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."86"')),'null','') AS `calf_tag_id_sec`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."78"')),'null','') AS `Calf_weight`, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(`core_animal_event`.`additional_attributes`, '$."99"')),'null','') AS `calf_weight_known`,
      replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."461"')),'null','') AS ease_of_calving_other,
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."233"')),'null','') AS calving_method,
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."460"')),'null','') AS calving_type_other, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."69"')),'null','') AS types_calving, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."70"')),'null','') AS ease_of_calving,
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."72"')),'null','') AS calving_status,
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."81"')),'null','') AS use_of_calf,
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."97"')),'null','') AS use_of_calf_other,
 replace(core_animal_event.lactation_id,'null','') AS lactation_id,
 replace(core_animal_event.lactation_number,'null','') AS lactation_number, 
 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."87"')),'null','') AS calf_tag_id, 
core_animal_event.id AS event_id,
auth_users.name as created_by,
core_animal_event.migration_id,
core_animal_event.odk_form_uuid,		
DATE_FORMAT(replace(core_animal_event.created_at,'null',''),'%Y-%m-%d') AS created_at,
DATE_FORMAT(replace(core_animal_event.updated_at,'null',''),'%Y-%m-%d') AS updated_at, 
updated.name  updated_by
 FROM core_animal_event 
 LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
 LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id       
 WHERE core_animal_event.id = _event_id;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_specific_pd_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_specific_pd_view`(_event_id integer)
BEGIN
	SELECT
    core_animal_event.id as event_id,
    core_animal_event.animal_id as animal_id,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."131"')),'null','') AS pd_results,
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."128"')),'null','') AS is_service_date_known, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."133"')),'null','') AS body_score, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."134"')),'null','') AS cost, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."130"')),'null','') AS exam_time, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."135"')),'null','') AS pd_method,
	DATE_FORMAT(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."129"')),'null',''),'%Y-%m-%d') AS service_date, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."132"')),'null','') AS pd_stage, 
	DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS exam_date, 
	DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS examination_date, 
	ifnull(replace(core_animal_event.field_agent_id,'null',''),'') AS field_agent_id,	
	auth_users.name as created_by,
	core_animal_event.migration_id,
	core_animal_event.odk_form_uuid,		
	DATE_FORMAT(replace(core_animal_event.created_at,'null',''),'%Y-%m-%d') AS created_at,
	DATE_FORMAT(replace(core_animal_event.updated_at,'null',''),'%Y-%m-%d') AS updated_at, 
	updated.name  updated_by
 FROM core_animal_event 
 LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
 LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id       
 WHERE core_animal_event.id = _event_id;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_specific_weight_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_specific_weight_view`(_event_id integer)
BEGIN
	 SELECT 
		  core_animal_event.animal_id as animal_id, 
          core_animal_event.id as event_id, 
		  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."138"')),'null','') AS body_length, 
		  JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."139"')) AS body_score,	
		  DATE_FORMAT(core_animal_event.event_date,'%Y-%m-%d') AS event_date,      
		  ifnull(core_animal_event.field_agent_id,'') AS field_agent_id, 
		  JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."137"')) AS heart_girth, 
		  core_animal_event.id AS Event_ID, 
		  JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."136"')) AS weight,
		  auth_users.name as created_by,
          core_animal_event.migration_id,
          core_animal_event.odk_form_uuid,
          core_animal_event.created_at,
          core_animal_event.updated_at,
          updated.name  updated_by
     FROM core_animal_event 
     LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
     LEFT JOIN  auth_users updated ON core_animal_event.updated_by = updated.id       
	 WHERE core_animal_event.id = _event_id ;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_sync_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_sync_view`(_animal_id integer)
BEGIN
    SELECT 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."120"')),'null','') AS hormone_type_id,
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 76) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."120"'))))) AS hormone_type, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."117"')),'null','') AS sync_number_id, 
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 75) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."117"'))))) AS sync_number, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."122"')),'null','') AS hormone_source_id, 
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 74) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."122"'))))) AS hormone_source, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."125"')),'null','') AS sync_person_id,
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 77) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."125"'))))) AS sync_person, 	
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."124"')),'null','') AS sync_cost, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."121"')),'null','') AS other_hormone_type_id, 
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 74) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."121"'))))) AS other_hormone_type, 	
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."118"')),'null','') AS animal_parity, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."123"')),'null','') AS other_hormone_source_id, 
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 76) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."123"'))))) AS other_hormone_source, 	
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."119"')),'null','') AS sync_time, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."126"')),'null','') AS sync_other_person, 
	(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 77) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."126"'))))) AS sync_person, 
	replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."127"')),'null','') AS sync_person_phone, 
	DATE_FORMAT(replace(core_animal_event.data_collection_date,'null',''),'%Y-%m-%d') AS sync_date, 
	DATE_FORMAT(replace(core_animal_event.event_date,'null',''),'%Y-%m-%d') AS event_date, 
	ifnull(replace(core_animal_event.field_agent_id,'null',''),'') AS field_agent_d, 
	core_animal_event.id AS event_id,
    DATE_FORMAT(ifnull(replace(core_animal_event.created_at,'null',''),''),'%Y-%m-%d') AS date_created,
	ifnull(auth_users.name,'') as created_by
	FROM core_animal_event
	LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
    WHERE core_animal_event.event_type = 5
	AND core_animal_event.animal_id = _animal_id ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_event_weight_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_event_weight_view`(_animal_id integer)
BEGIN
	 SELECT 
		  core_animal_event.animal_id as animal_id, 
		  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."138"')),'null','') AS body_length, 
		  JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."139"')) AS body_score_id, 
		  (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 71) AND (list.value = JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."139"'))))) AS body_score, 		 
		  DATE_FORMAT(core_animal_event.event_date,'%Y-%m-%d') AS event_date,      
		  ifnull(core_animal_event.field_agent_id,'') AS field_agent_id, 
		  JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."137"')) AS heart_girth, 
		  core_animal_event.id AS Event_ID, 
		  JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."136"')) AS weight_kg,
		  auth_users.name as created_by     
     FROM core_animal_event 
     LEFT JOIN auth_users ON core_animal_event.created_by = auth_users.ID 
     WHERE core_animal_event.event_type = 6     
	 AND core_animal_event.animal_id = _animal_id 
     ORDER BY core_animal_event.event_date DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_graduation_list_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_graduation_list_create`(_org_id integer)
BEGIN
	/* 
       Graduation Criteria
       ----------------------
	    1. FEMALE-CALF-TO-HEIFER
		2. MALE-CALF-TO-BULL
		3. FEMALE-CALF-TO-COW 
	*/
    
    
    /*
		Get animals with the below criteria
        1. Animal that are not cows or bulls
        2. Remove animals below 4 months. Not subject to any graduation
        3. Remove all animals that are not are on the graduation list but not processed
        4. Store this data in a temporary table. Records will be deleted once done with them
    */
    
    /*check if background is activated or not */
    SET @is_activated = ( SELECT count(org_id) FROM interface_background_processes WHERE status_id = 0 AND org_id = _org_id);
    
    IF (@is_activated = 0) THEN
		SET @uuid  = uuid();
		INSERT INTO interface_temp_graduation_list(animal_id,animal_type,birthdate,age_months,uuid)
		SELECT id,animal_type,birthdate,TIMESTAMPDIFF(MONTH,birthdate,NOW()),@uuid FROM core_animal 
		WHERE org_id =  _org_id 
		AND birthdate IS NOT NULL
		AND (animal_type NOT IN(2,5))
		AND id NOT IN (SELECT animal_id FROM interface_graduation_list WHERE status_id = 0)
		AND TIMESTAMPDIFF(MONTH,birthdate,NOW()) > 4;   
		
		IF EXISTS(SELECT * FROM  interface_temp_graduation_list WHERE uuid = @uuid) 
		THEN
		   /* Get Graduation Settings*/
		   SET  @default_female_calf_to_heifer  = (SELECT graduation_value FROM interface_graduation_settings WHERE org_id = 0 OR org_id IS NULL AND graduation_parameter = 'FEMALE-CALF-TO-HEIFER' LIMIT 1);
		   SET  @default_male_calf_to_bull  = (SELECT graduation_value FROM interface_graduation_settings WHERE org_id = 0 OR org_id IS NULL AND graduation_parameter = 'MALE-CALF-TO-BULL' LIMIT 1);
		   SET  @default_heifer_to_cow  = (SELECT graduation_value FROM interface_graduation_settings WHERE org_id = 0 OR org_id IS NULL AND graduation_parameter = 'FEMALE-CALF-TO-COW' LIMIT 1);
		   
		   SET  @female_calf_to_heifer  = (SELECT graduation_value FROM interface_graduation_settings WHERE org_id = 0 OR _org_id IS NULL AND graduation_parameter = 'FEMALE-CALF-TO-HEIFER' LIMIT 1);
		   SET  @male_calf_to_bull  = (SELECT graduation_value FROM interface_graduation_settings WHERE org_id = 0 OR _org_id IS NULL AND graduation_parameter = 'MALE-CALF-TO-BULL' LIMIT 1);
		   SET  @heifer_to_cow  = (SELECT graduation_value FROM interface_graduation_settings WHERE org_id = 0 OR _org_id IS NULL AND graduation_parameter = 'FEMALE-CALF-TO-COW' LIMIT 1);
		   
		
			/* Graduate from female calf(4) to heifer(1)*/		
			INSERT INTO interface_graduation_list(animal_id,graduate_from,graduate_to,status_id,graduation_process_id,uuid,created_at,created_by)
			SELECT animal_id, animal_type, 1, 0, 1, @uuid,now(),null FROM interface_temp_graduation_list WHERE uuid = @uuid AND animal_type = 4 AND age_months >=IFNULL(@female_calf_to_heifer,@default_female_calf_to_heifer);
			
			 /* Graduate from male calf(3) to bull(5) */		
			INSERT INTO interface_graduation_list(animal_id,graduate_from,graduate_to,status_id,graduation_process_id,uuid,created_at,created_by)
			SELECT animal_id, animal_type, 5, 0, 2, @uuid,now(),null FROM interface_temp_graduation_list WHERE uuid = @uuid AND animal_type = 3 AND age_months >= IFNULL( @male_calf_to_bull, @default_male_calf_to_bull);
			
			
			/* Graduate from heifer(1) to cow (2)*/
			INSERT INTO interface_graduation_list(animal_id,graduate_from,graduate_to,status_id,graduation_process_id,uuid,created_at,created_by)
			SELECT animal_id, animal_type, 2, 0, 3, @uuid,now(),null FROM interface_temp_graduation_list WHERE uuid = @uuid AND animal_type = 1 AND age_months >= IFNULL(@heifer_to_cow,@default_heifer_to_cow)
			AND animal_id IN (SELECT animal_id FROM core_animal_event WHERE event_type IN (1,2));
			
			 
			/*Deleted Staged Data*/
			DELETE FROM interface_temp_graduation_list WHERE uuid = @uuid;
		END IF;
      END IF;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_graduation_list_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_graduation_list_view`(_org_id integer,_status_id integer)
BEGIN
	SELECT a.id,a.animal_id,
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 62) AND (list.value = a.graduate_from ))) AS graduate_from,     
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 62) AND (list.value = a.graduate_to ))) AS graduate_to, 
    a.status_id,a.uuid,  a.action,
    DATE_FORMAT(replace(a.created_at,'null',''),'%Y-%m-%d') AS created_at,  
    a.created_by,   
	DATE_FORMAT(replace(a.updated_at,'null',''),'%Y-%m-%d') AS updated_at,
    a.updated_by, upper(b.name) name,upper(b.tag_id) tag_id
    FROM interface_graduation_list a
    JOIN core_animal b on b.id = a.animal_id
    WHERE b.org_id = _org_id AND a.status_id = _status_id;   
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_graduation_record_process` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_graduation_record_process`(_id integer, _option integer, _user integer)
BEGIN
    SET @_action = 'DID NOT GRADUATE';
    IF _option = 1 THEN    
		SELECT animal_id,graduate_to  INTO @animal_id, @graduate_to FROM interface_graduation_list WHERE id = _id;
        UPDATE core_animal SET animal_type = @graduate_to WHERE id = @animal_id;
        SET @_action = 'GRADUATED';
    END IF;    
    UPDATE interface_graduation_list SET status_id = 1, updated_at = now(), updated_by = _user, action = @_action  WHERE id = _id; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_graduation_record_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_graduation_record_view`(_id integer)
BEGIN
	SELECT a.id,a.animal_id,
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 62) AND (list.value = a.graduate_from ))) AS graduate_from,     
    (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 62) AND (list.value = a.graduate_to ))) AS graduate_to, 
    a.status_id,a.uuid,
    DATE_FORMAT(replace(a.created_at,'null',''),'%Y-%m-%d') AS created_at,  
    a.created_by,   
	DATE_FORMAT(replace(a.updated_at,'null',''),'%Y-%m-%d') AS updated_at,
    a.updated_by, upper(b.name) name,upper(b.tag_id) tag_id
    FROM interface_graduation_list a
    JOIN core_animal b on b.id = a.animal_id
    WHERE  a.id = _id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_graduation_settings_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_graduation_settings_view`(_org_id integer)
BEGIN
	IF EXISTS(SELECT * FROM interface_graduation_settings WHERE org_id = _org_id) 
THEN 
	SELECT id,org_id,description,graduate_from,graduate_to,created_at,created_by,updated_at,updated_by,'CUSTOM' AS SETTING_TYPE FROM interface_graduation_settings WHERE org_id = _org_id;
ELSE 
	SELECT id,org_id,description,graduate_from,graduate_to,created_at,created_by,updated_at,updated_by,'SYSTEM' AS SETTING_TYPE FROM interface_graduation_settings WHERE org_id = 0 OR org_id IS NULL ;
END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_lookup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_lookup`(IN list_type_ids VARCHAR(255))
BEGIN
  SET @sql = CONCAT('select a.list_type_id,b.name,a.label as value,a.value as id from core_master_list  a join core_master_list_type b on a.list_type_id = b.id and a.list_type_id IN (', list_type_ids, ')');
  PREPARE stmt FROM @sql;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_org_access_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_org_access_create`(_access varchar(50),_user_id integer, _created_by integer)
BEGIN
	IF EXISTS (SELECT * FROM interface_org_user_access WHERE user_id = _user_id) THEN
		UPDATE interface_org_user_access SET  orgs = _access, updated_at = now(), updated_by = _created_by
        WHERE user_id = _user_id;		
    ELSE
		INSERT INTO interface_org_user_access(user_id,orgs,created_at,created_by) VALUES(_user_id,_access,now(),_created_by);
    END IF; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_org_access_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_org_access_view`(_user_id integer)
BEGIN
    SET @ids = (SELECT  orgs FROM interface_org_user_access WHERE user_id = _user_id LIMIT 1);  
    
    IF( @ids IS NULL) THEN
		 SET @sql_str3 = 'SELECT id,name, 0 as status FROM core_organization WHERE is_active =1';
    ELSE
		SET @sql_str = CONCAT('SELECT id,name, 1 as status FROM core_organization WHERE is_active =1 AND id IN(',@ids,')');  
        SET @sql_str2 = CONCAT('SELECT id,name, 0 as status FROM core_organization WHERE is_active =1 AND id  NOT IN(',@ids,')'); 
	    SET @sql_str3 = CONCAT(@sql_str,' UNION ',@sql_str2); 
    END IF;	 
	PREPARE stmt1 FROM @sql_str3;
	EXECUTE stmt1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_org_all_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_org_all_view`()
BEGIN	
	SELECT id,name FROM core_organization;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_org_switch` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_org_switch`(_new_org integer, _user integer)
BEGIN
	UPDATE AUTH_USERS SET org_id = _new_org   
    WHERE id = _user;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_parameter_limit_view_all` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_parameter_limit_view_all`()
BEGIN 
	SELECT 
		param.id,
        param.category,
        param.description,
        param.message,
        param.min_value,
        param.max_value,
        param.is_active AS is_active_id,
        (SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 67) AND (list.value = param.is_active))) AS is_active,
		param.org_id    
        FROM interface_limit_parameters param;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_parameter_limit_view_one` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_parameter_limit_view_one`(_id integer)
BEGIN 
	SELECT param.id,param.category,param.description,param.message,param.min_value,param.max_value,param.is_active,param.org_id, updated.name updated_by,auth_users.name as created_by FROM interface_limit_parameters param 
    LEFT JOIN auth_users ON param.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON param.updated_by = updated.id   
    WHERE param.id = _id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_parameter_local_system_settings_view_all` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_parameter_local_system_settings_view_all`(_org_id integer)
BEGIN 
	SELECT 		 
		setting.id,
		setting.name,
        setting.key,
		setting.value,        
		setting.is_active as is_active_id,
		(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 67) AND (list.value = setting.is_active))) AS is_active,
		setting.description,
		setting.org_id,
		setting.farm_id,
		setting.created_by,
		setting.created_at,
		setting.updated_by,
		setting.updated_at 
	FROM interface_local_settings setting
    WHERE org_id = _org_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_parameter_local_system_settings_view_one` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_parameter_local_system_settings_view_one`(_id integer)
BEGIN 
SELECT 		 
		setting.id,
		setting.name,
        setting.key,
		setting.value,
		setting.is_active as is_active,		
		setting.description,
		setting.org_id,
		setting.farm_id,		
		DATE_FORMAT(setting.created_at,'%Y-%m-%d') as created_at,		
		DATE_FORMAT(setting.updated_at,'%Y-%m-%d') as updated_at,
        updated.name updated_by,
        auth_users.name as created_by
	FROM interface_local_settings setting 
    LEFT JOIN auth_users ON setting.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON setting.updated_by = updated.id   
    WHERE setting.id = _id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_send_to_posting_queue_batch_records_milking` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_send_to_posting_queue_batch_records_milking`(_uuid varchar(250))
BEGIN   
	UPDATE  interface_batch_uploads SET step = 2
    WHERE uuid = _uuid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_service_provider_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_service_provider_create`(_name varchar(255), _acronym varchar(255), _service_provider_type int, _country int,postal_address varchar(255), _postal_code varchar(255), _city varchar(255), _phone varchar(255),_email varchar(255), _description varchar(255), _services_offered varchar(255), _contact_person varchar(255), _contact_person_mobile_number varchar(255), _org_id int, _created_by int)
BEGIN  
   INSERT INTO interface_service_providers (name,acronym,service_provider_type,country,postal_address,postal_code,
   city,phone,email,description,services_offered,contact_person,contact_person_mobile_number,org_id,created_at,created_by)
   values (_name, _acronym, _service_provider_type, _country,postal_address, _postal_code, _city, _phone,_email, _description, _services_offered, _contact_person, _contact_person_mobile_number, _org_id, now(), _created_by);
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_service_provider_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_service_provider_update`(_record_id int,_name varchar(255), _acronym varchar(255), _service_provider_type int, _country int,postal_address varchar(255), _postal_code varchar(255), _city varchar(255), _phone varchar(255),_email varchar(255), _description varchar(255), _services_offered varchar(255), _contact_person varchar(255), _contact_person_mobile_number varchar(255), _org_id int, _updated_by int)
BEGIN  
   UPDATE interface_service_providers SET name = _name,acronym = _acronym,service_provider_type = _service_provider_type,country = _country,postal_address = postal_address,postal_code = _postal_code,
   city = _city,phone = _phone,email = _email,description = _description,services_offered = _services_offered,contact_person = _contact_person,contact_person_mobile_number = _contact_person_mobile_number,
   org_id = _org_id,updated_at = now(),updated_by = _updated_by  
   where id = _record_id;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_service_provider_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_service_provider_view`(_id int,_option int)
BEGIN
   /* 
     options
     ------------
      value   	Description
       0  		view all records that belong to an org/farm. _id paramer value is org id
       1        view a specific record. _id paramer value is record id
   
   */
   IF _option = 0 THEN
	SELECT sp.id, sp.name, sp.acronym,sp.postal_address,sp.postal_code,sp.city,sp.phone,
		sp.email, sp.description,sp.services_offered,sp.contact_person,sp.contact_person_mobile_number,
		DATE_FORMAT(sp.created_at,'%Y-%m-%d') as created_at,
		DATE_FORMAT(sp.updated_at,'%Y-%m-%d') as updated_at,		
		sp.service_provider_type as service_provider_type_id,
		(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 84) AND (list.value = sp.service_provider_type))) AS service_provider_type_name,
		cnt.name as country,
        sp.country as country_id,
		updated.name updated_by,    
		auth_users.name as created_by 
	FROM interface_service_providers sp
	LEFT JOIN core_country cnt ON cnt.id = sp.country
	LEFT JOIN auth_users ON sp.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON sp.updated_by = updated.id
	WHERE sp.org_id = _id;		
  ELSE  
	SELECT sp.id, sp.name, sp.acronym,sp.postal_address,sp.postal_code,sp.city,sp.phone,
		sp.email, sp.description,sp.services_offered,sp.contact_person,sp.contact_person_mobile_number,
		DATE_FORMAT(sp.created_at,'%Y-%m-%d') as created_at,
		DATE_FORMAT(sp.updated_at,'%Y-%m-%d') as updated_at,
		sp.service_provider_type as service_provider_type_id,
		(SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 84) AND (list.value = sp.service_provider_type))) AS service_provider_type_name,
		sp.country as country_id,
        cnt.name as country,
		updated.name updated_by,    
		auth_users.name as created_by 
	FROM interface_service_providers sp
	LEFT JOIN core_country cnt ON cnt.id = sp.country
	LEFT JOIN auth_users ON sp.created_by = auth_users.ID 
	LEFT JOIN  auth_users updated ON sp.updated_by = updated.id
	WHERE sp.id = _id;
  END IF;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_set_milking_parameters` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_set_milking_parameters`(_animal_id integer,_milk_date date)
BEGIN
/*
	1. Set lactation id - Get the calving ID of the last calving
    2. Set lactation number -  The number of times a cow has given birth. Obtain from calving event data
    3. Set Test Day No -  Total number of milking records + 1 for the current lactation. 
    4. Days in Milk - Number of days between calving date & Milk date
*/
    
/* SET LACTATTON ID */
	SELECT a.id  , a.lactation_number,a.event_date  INTO @lactation_id,@lactation_number,@calving_date FROM core_animal_event A 
	JOIN
	(SELECT MAX(ID) as lactation_id FROM (
		SELECT ID				
		FROM core_animal_event
		WHERE event_type = 1
		AND animal_id  = _animal_id
		AND event_date = ( SELECT MAX(event_date) FROM core_animal_event WHERE `core_animal_event`.`event_type` = 1 AND animal_id  = 340434 LIMIT 1)
		) as max_id 
	) B
	ON A. id = B.lactation_id;    
    SET @days_in_milk = DATEDIFF(_milk_date,@calving_date);
    
    SELECT count(id)+1 INTO  @test_day_no FROM core_animal_event 
    WHERE animal_id  =  _animal_id and event_type = 2 and lactation_id = @lactation_id;
    SELECT @lactation_id lactation_id, @lactation_number lactation_number, @calving_date calving_date, @days_in_milk days_in_milk, @test_day_no test_day_no;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_stats_breeds` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_stats_breeds`(_org_id integer)
BEGIN
SELECT  breed, COUNT(breed) FROM
	(
		 SELECT
		 ifnull((SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 8) AND (list.value = a.main_breed))),'Unallocated') AS breed
		 FROM core_animal a 
		 WHERE org_id = _org_id 
		 AND a.id NOT IN (SELECT animal_id FROM core_animal_event WHERE event_type = 9)
	 ) AS aggregated
 GROUP BY breed;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_stats_breed_distribution` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_stats_breed_distribution`(_org_id integer)
BEGIN
SELECT  
	breed, 
    COUNT(breed) count,
	(round((COUNT(breed) / ( SELECT COUNT( * ) FROM core_animal WHERE org_id = _org_id AND id not in (SELECT animal_id FROM core_animal_event WHERE event_type = 9) )) * 100 ,1)) AS percentage	
FROM
	(
		 SELECT
		 ifnull((SELECT list.label  FROM  core_master_list list WHERE ((list.list_type_id = 8) AND (list.value = a.main_breed))),'Unallocated') AS breed
		 FROM core_animal a 
		 WHERE org_id = _org_id 
		 AND a.id NOT IN (SELECT animal_id FROM core_animal_event WHERE event_type = 9)
	 ) AS aggregated
 GROUP BY breed;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_stats_dashboard_overview` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_stats_dashboard_overview`(_org_id integer)
BEGIN
	/*
		1. Active Animals -  compare with  last year
        2. Milk - compare with same period last year
        3. New Births -  compared to same period last year
        4. Net movement - Herd Entry Exit net effect -  current year only
	*/
		SET @current_year = YEAR(CURDATE());
		SET @previous_year = @current_year - 1;
        
        SET @today  = CURDATE();
        SET @this_date_prev_year =  DATE_SUB(CURDATE(), INTERVAL 1 YEAR);
        SET @this_year_start =  MAKEDATE(year(now()),1);
        SET @prev_year_start =  DATE_SUB(@this_year_start, INTERVAL 1 YEAR);
        
         
         /* MILK PRODUCTION */
         /* previous year same date*/
         SELECT
		 ROUND(SUM(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."61"')),'null','')+ 
		 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."68"')),'null','')+
		 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."59"')),'null','')),2) 
         into @prev_year_total_milk		 
         FROM core_animal_event  
		 LEFT JOIN core_animal on core_animal.id = core_animal_event.animal_id
		 WHERE (core_animal_event.event_type = 2)
		 AND core_animal.org_id = _org_id 
		 AND YEAR(core_animal_event.event_date) BETWEEN @prev_year_start AND @this_date_prev_year;
         
		/* current  year today*/
        SELECT
		 ROUND(SUM(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."61"')),'null','')+ 
		 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."68"')),'null','')+
		 replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."59"')),'null','')),2)
         into @current_year_total_milk		 
         FROM core_animal_event  
		 LEFT JOIN core_animal on core_animal.id = core_animal_event.animal_id
		 WHERE (core_animal_event.event_type = 2)
		 AND core_animal.org_id = _org_id 
		 AND YEAR(core_animal_event.event_date) BETWEEN @this_year_start AND @today;
         
         /* Milk % change */
         SET @prev_year_total_milk = IFNULL(@prev_year_total_milk,0);
         SET @current_year_total_milk = IFNULL(@current_year_total_milk,0);
         SET @milk_change_percentage = IFNULL(round(((@current_year_total_milk - @prev_year_total_milk)/@prev_year_total_milk)*100,1),0);
         
         /* NEW CALVING BIRTHS - compared to same time last year*/
		 /* previous year same date*/
         SELECT
		 COUNT(core_animal_event.id)
         into @prev_year_births		 
         FROM core_animal_event  
		 LEFT JOIN core_animal on core_animal.id = core_animal_event.animal_id
		 WHERE (core_animal_event.event_type = 1)
		 AND core_animal.org_id = _org_id 
		 AND YEAR(core_animal_event.event_date) BETWEEN @prev_year_start AND @this_date_prev_year;
         
		/* current  year today*/
        SELECT
		COUNT(core_animal_event.id)
         into @current_year_births		 
         FROM core_animal_event  
		 LEFT JOIN core_animal on core_animal.id = core_animal_event.animal_id
		 WHERE (core_animal_event.event_type = 1)
		 AND core_animal.org_id = _org_id 
		 AND YEAR(core_animal_event.event_date) BETWEEN @this_year_start AND @today;
         
		SET @birth_change_percentage = IFNULL(round(((@current_year_births - @prev_year_births)/@prev_year_births)*100,1),0);
         
		/* NET MOVEMENT */
        SET @current_year_exits = (SELECT count(id)  FROM core_animal WHERE org_id = _org_id
         AND id IN (SELECT animal_id FROM core_animal_event WHERE event_type = 9 AND YEAR(event_date) = @current_year));
        
        SET @current_year_entrants = (SELECT COUNT(id) FROM core_animal where org_id = _org_id AND YEAR(reg_date) = @current_year);
                 
        SET @current_year_net_movement  =   @current_year_entrants - @current_year_exits;
        
        
        /* ACTIVE ANIMALS */
         SELECT count(id) INTO @current_year_active_animals  FROM core_animal WHERE org_id = _org_id
         AND id NOT IN (SELECT animal_id FROM core_animal_event WHERE event_type = 9);
         
         SET @prev_year_active_animals = @current_year_active_animals - @current_year_net_movement;
         SET @active_animals_change_percentage = IFNULL(round(((@current_year_active_animals - @prev_year_active_animals)/@prev_year_active_animals)*100,1),0);
                 
         SELECT @prev_year_total_milk prev_year_total_milk,
				@current_year_total_milk current_year_total_milk,
                @milk_change_percentage milk_change_percentage,
                @current_year_births current_year_births,
                @prev_year_births prev_year_births,
                @birth_change_percentage birth_change_percentage,
                @current_year_exits current_year_exits,
                @current_year_entrants current_year_entrants,
                @current_year_net_movement current_year_net_movement,
                @current_year_active_animals current_year_active_animals,
                @active_animals_change_percentage active_animals_change_percentage;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_stats_milk_pre_cur_year_comparison` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_stats_milk_pre_cur_year_comparison`(_org_id integer)
BEGIN
	SET @current_year = YEAR(CURDATE());
    SET @previous_year = @current_year - 1;
    
    SELECT A.YR, A.MN, ifnull(B.MILK,0) AS MILK
    FROM
    (
		select @current_year YR ,1 MN UNION
		select @current_year YR ,2 MN UNION
		select @current_year YR ,3 MN UNION
		select @current_year YR ,4 MN UNION
		select @current_year YR ,5 MN UNION
		select @current_year YR ,6 MN UNION
		select @current_year YR ,7 MN UNION
		select @current_year YR ,8 MN UNION
		select @current_year YR ,9 MN UNION
		select @current_year YR ,10 MN UNION
		select @current_year YR ,11 MN UNION
		select @current_year YR ,12 MN UNION
		select @previous_year YR ,1 MN UNION
		select @previous_year YR ,2 MN UNION
		select @previous_year YR ,3 MN UNION
		select @previous_year YR ,4 MN UNION
		select @previous_year YR ,5 MN UNION
		select @previous_year YR ,6 MN UNION
		select @previous_year YR ,7 MN UNION
		select @previous_year YR ,8 MN UNION
		select @previous_year YR ,9 MN UNION
		select @previous_year YR ,10 MN UNION
		select @previous_year YR ,11 MN UNION
		select @previous_year YR ,12 MN
    )  A    
    LEFT JOIN
    ( 
     SELECT YR,MN,ROUND(SUM(aggregate_milk),2) MILK FROM
        (
			SELECT  
			  YEAR(core_animal_event.event_date) YR,
			  MONTH(core_animal_event.event_date) MN, 	 
			  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."61"')),'null','')+ 
			  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."68"')),'null','')+
			  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."59"')),'null','') aggregate_milk				
			 FROM core_animal_event  
			 LEFT JOIN core_animal on core_animal.id = core_animal_event.animal_id
			 WHERE (core_animal_event.event_type = 2)
			 AND core_animal.org_id = _org_id 
			 AND YEAR(core_animal_event.event_date) BETWEEN @previous_year AND @current_year
			) AS AGGREGATED_DATA
        GROUP BY MN,YR
	) B
    
    ON A.MN = B.MN AND A.YR = B.YR
    ORDER BY A.YR,A.MN;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_stats_top_cows` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_stats_top_cows`(_org_id integer,_start_date date,_end_date date)
BEGIN
SELECT * FROM (SELECT 
  core_animal_event.animal_id,
  core_animal.name,
  core_animal.tag_id,  
  ROUND(SUM(replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."61"')),'null','') + 
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."68"')),'null','') +
  replace(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."59"')),'null','')),2) AS total_milk
 FROM core_animal_event  
 LEFT JOIN core_animal on core_animal.id = core_animal_event.animal_id
 WHERE (core_animal_event.event_type = 2)
 AND core_animal.org_id = _org_id
 AND core_animal_event.event_date BETWEEN _start_date AND _end_date
 GROUP BY core_animal_event.animal_id
 )  AS aggregated_data order by total_milk DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_animal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_animal`(
_animal_id integer,_updated_by integer,_animal_type integer,_birthdate date,_name varchar(100),_breed_composition integer,_hair_sample_id integer,_main_breed integer,_reg_date date,_sex integer,_tag_id varchar(100),
_breed_combination varchar(100),_notes varchar(100),_tag_prefix varchar(100),_tag_sequence varchar(100),_breed_composition_details varchar(100),_color integer,_color_other varchar(100),_country_of_origin varchar(100),
_deformities integer,_entry_date date,_entry_type integer,_herd_book_number varchar(100),_main_breed_other varchar(100),_purchase_cost decimal(17,2),_secondary_breed integer,_secondary_breed_other varchar(100),
_sire_type integer,_sire_id integer, _dam_id integer,_herd_id integer, _org_id integer,_farm_id integer
)
BEGIN 
	SET @dam_tag = (SELECT ifnull(dam_tag_id,'') from core_animal where dam_id = _dam_id LIMIT 1);
    SET @sire_tag = (SELECT ifnull(sire_tag_id,'') from core_animal where sire_id = _sire_id LIMIT 1);
    SET @additional_attributes = JSON_MERGE_PRESERVE( 
		JSON_OBJECT('147', ifnull( _breed_combination,'')), 
		JSON_OBJECT('226', ifnull( _notes,'')),
		JSON_OBJECT('57', ifnull( _tag_prefix,'')),  
		JSON_OBJECT('58', ifnull( _tag_sequence,'')),
		JSON_OBJECT('223', ifnull( _breed_composition_details,'')),
		JSON_OBJECT('254', ifnull( _color,0)),
		JSON_OBJECT('456', ifnull( _color_other,'')),
		JSON_OBJECT('232', ifnull( _country_of_origin,'')),
		JSON_OBJECT('249', ifnull( _deformities,0)),
		JSON_OBJECT('253', ifnull(_entry_date,'')), 
		JSON_OBJECT('252', ifnull( _entry_type,0)), 
		JSON_OBJECT('224', ifnull( _herd_book_number,'')), 
		JSON_OBJECT('457', ifnull( _main_breed_other,'')), 
		JSON_OBJECT('251', ifnull( _purchase_cost,0)), 
		JSON_OBJECT('458', ifnull( _secondary_breed,0)), 
		JSON_OBJECT('459', ifnull( _secondary_breed_other,'')), 
		JSON_OBJECT('231', '')
	); 
    SELECT _entry_date;
      
	 UPDATE core_animal SET 
		 animal_type = _animal_type,
		 birthdate = _birthdate,
		 name = _name,
		 breed_composition = _breed_composition,
		 hair_sample_id = _hair_sample_id,
		 main_breed = _main_breed,
		 reg_date = _reg_date,
		 sex = _sex,
		 tag_id = _tag_id,
		 additional_attributes = @additional_attributes,
		 updated_at = curdate(),
		 updated_by = _updated_by,   
		 sire_type = _sire_type,
		 sire_id = _sire_id,
		 sire_tag_id = @sire_tag_id,
		 dam_id = _dam_id,
		 dam_tag_id = @dam_tag_id,
		 herd_id = _herd_id,
		 org_id = _org_id,
		 farm_id = _farm_id
     WHERE id  =  _animal_id;      
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_calving` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_calving`(
_event_id integer,_calving_date date,_birth_type integer,_body_condition_score integer,_calf_color integer,_calf_deformities integer,_other_calf_deformities varchar(100), _heart_girth decimal(10,2),_calf_name varchar(100), _calf_sex integer,_calf_weight decimal(10,2),
_ease_of_calving_other varchar(100), _calving_method integer,_calving_type_other varchar(100),_calving_type integer,_ease_of_calving integer,_calving_status integer,_use_of_calf integer,_use_of_calf_other varchar(100),_calf_tag_id varchar(100),
_lactation_number varchar(100),_field_agent_id integer,_updated_by integer)
BEGIN 

    SET @additional_attributes = JSON_MERGE_PRESERVE(    
		JSON_OBJECT('71', ifnull( _birth_type,0)),        
        JSON_OBJECT('80', ifnull(_body_condition_score,'')),
        JSON_OBJECT('88', ifnull(_calf_color,'')),
        JSON_OBJECT('77', ifnull(_calf_deformities,'')),
        JSON_OBJECT('98', ifnull(_other_calf_deformities,'')), 
        JSON_OBJECT('79', ifnull(_heart_girth,0)),
        JSON_OBJECT('84', ifnull(_calf_name,0)), 
        JSON_OBJECT('73', ifnull(_calf_sex,'')),
        JSON_OBJECT('78', ifnull(_calf_weight,'')),
        JSON_OBJECT('461', ifnull(_ease_of_calving_other,0)), 
        JSON_OBJECT('233', ifnull(_calving_method,0)),
        JSON_OBJECT('460', ifnull(_calving_type_other,0)),
        JSON_OBJECT('69', ifnull(_calving_type,0)),
        JSON_OBJECT('70', ifnull(_ease_of_calving,0)),
        JSON_OBJECT('72', ifnull(_calving_status,0)),
        JSON_OBJECT('81', ifnull(_use_of_calf,0)),
        JSON_OBJECT('97', ifnull(_use_of_calf_other,0)),        
        JSON_OBJECT('87', ifnull(_calf_tag_id,0))       
	);  
     UPDATE core_animal_event SET event_date = _calving_date,data_collection_date = _calving_date,field_agent_id =_field_agent_id,
     additional_attributes = @additional_attributes, updated_at = CURDATE() ,updated_by = _updated_by,lactation_number = _lactation_number
     WHERE id  = _event_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_exits` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_exits`(
_event_id integer,_exit_date date,_disposal_amount decimal(17,2),_disposal_reason integer,_disposal_reason_other varchar(100),_new_breeder_name varchar(100),_new_breeder_phone_number varchar(100),
_new_country integer,_new_district integer,_new_farmer_name varchar(100) ,_new_farmer_phone_number varchar(100),_new_region integer,_new_village integer,
_field_agent_id integer,_updated_by integer)
BEGIN

    SET @additional_attributes = JSON_MERGE_PRESERVE(     
		JSON_OBJECT('245', ifnull( _disposal_amount,0)),
        JSON_OBJECT('247', ifnull( _disposal_reason,'')),
		JSON_OBJECT('246', ifnull( _disposal_reason_other,'')),
        JSON_OBJECT('237', ifnull( _new_breeder_name,'')),
        JSON_OBJECT('236', ifnull( _new_breeder_phone_number,'')),       
        JSON_OBJECT('244', ifnull( _new_country,0)),
        JSON_OBJECT('242', ifnull( _new_district,0)),        
		JSON_OBJECT('238', ifnull( _new_farmer_name,'')),
		JSON_OBJECT('239', ifnull( _new_farmer_phone_number,'')),
        JSON_OBJECT('243', ifnull( _new_region,0)),        
        JSON_OBJECT('240', ifnull( _new_village,0))
	);  
     UPDATE core_animal_event SET event_date = _exit_date,data_collection_date =_exit_date,field_agent_id = _field_agent_id,
     additional_attributes = @additional_attributes,updated_at = CURDATE(),updated_by = _updated_by
     WHERE id = _event_id;     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_health` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_health`(
_event_id integer,_health_date date,_health_category varchar(100),_drug_cost decimal(17,2),_health_provider integer,_health_type integer,_other_health_type varchar(100),_field_agent_id integer,_updated_by integer)
BEGIN	 
    SET @additional_attributes = JSON_MERGE_PRESERVE(
		JSON_OBJECT('141', ifnull(_health_category,'')),
        JSON_OBJECT('145', ifnull(_drug_cost,0)),
		JSON_OBJECT('144', ifnull(_health_provider,0)),
        JSON_OBJECT('142', ifnull(_health_type,0)),
        JSON_OBJECT('143', ifnull(_other_health_type,'')) 
	);  
     UPDATE core_animal_event SET event_date = _health_date,data_collection_date =_health_date,field_agent_id = _field_agent_id,
     additional_attributes = @additional_attributes,updated_at =CURDATE() ,updated_by = _updated_by
     WHERE id = _event_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_insemination` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_insemination`(
_event_id integer,_ai_date date,_straw_semen_type integer,_type_of_ai integer,_straw_id varchar(50),_country_of_origin varchar(50),
_body_condition_score integer,_breed_composition_bull integer,_ai_cost DECIMAL(15,2),_cow_weight DECIMAL(15,2),_semen_batch varchar(100),
_semen_source integer,_semen_source_other varchar(100),_breed_of_bull integer,_breed_of_bull_other varchar(100),
_field_agent_id integer,_updated_by integer)
BEGIN	 
    SET @additional_attributes = JSON_MERGE_PRESERVE(		
        JSON_OBJECT('106', ifnull( _straw_semen_type,0)),
        JSON_OBJECT('105', ifnull( _type_of_ai,0)),
        JSON_OBJECT('107', ifnull( _straw_id,'')),
        JSON_OBJECT('110', ifnull( _country_of_origin,0)),
        JSON_OBJECT('103', ifnull( _ai_date,0)),
        
		JSON_OBJECT('104', ifnull( _body_condition_score,0)),
		JSON_OBJECT('113', ifnull( _breed_composition_bull,0)),
        JSON_OBJECT('114', ifnull( _ai_cost,0)),
        JSON_OBJECT('115', ifnull( _cow_weight,0)),
		JSON_OBJECT('116', ifnull( _semen_batch,'')),
        
        JSON_OBJECT('108', ifnull( _semen_source,0)),
        JSON_OBJECT('109', ifnull( _semen_source_other,'')),
        JSON_OBJECT('111', ifnull( _breed_of_bull,0)),
        JSON_OBJECT('112', ifnull( _breed_of_bull_other,''))
	);  
     UPDATE core_animal_event SET event_date = _ai_date,data_collection_date = _ai_date,field_agent_id = _field_agent_id,
     additional_attributes = @additional_attributes,updated_at = CURDATE() ,updated_by = _updated_by
     WHERE id = _event_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_menu_setup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_menu_setup`(
    _calving tinyint,
    _milking tinyint,
    _health tinyint,
    _bio_data tinyint,
    _insemination tinyint,
    _sync tinyint,
    _exit tinyint,
    _weight tinyint,
    _pd tinyint,
    _updated_by integer,
    _animal_type_id integer
)
BEGIN

	UPDATE interface_animal_event_menus_setup SET
	calving = _calving,
    milking = _milking,
    health = _health,
    bio_data = _bio_data,
    insemination = _insemination,
    sync = _sync,
	`exit` = _exit,
    weight = _weight,
    pd = _pd,
    updated_by = _updated_by,
    updated_at = now()    
    WHERE animal_type = _animal_type_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_milking` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_milking`(
_event_id integer,_milk_date date,_days_in_milk integer,_lactation_id integer,_lactation_number integer,_milking_notes varchar(300)
,_milk_sample_type_id integer,_milk_pm_litres float,_milk_butter_fat float,_milk_lactose float,_milk_mid_day float,_milk_protein float,
_milk_am_litres float,_milk_somatic_cell_count bigint,_milk_urea float,_testday_no integer,_milk_Weight float,
_field_agent_id integer,_updated_by integer)
BEGIN
	 
    SET @milk_composite_litres = ifnull(_milk_am_litres,0) + ifnull(_milk_mid_day,0) + ifnull(_milk_pm_litres,0);     
    SET @additional_attributes = JSON_MERGE_PRESERVE(
        JSON_OBJECT('209', _milk_Weight),
        JSON_OBJECT('67', _milk_urea),
        JSON_OBJECT('66',_milk_somatic_cell_count),
        JSON_OBJECT('59', ifnull( _milk_am_litres,0)),
        JSON_OBJECT('64', _milk_protein),
         
		JSON_OBJECT('68', ifnull( _milk_mid_day,0)),
		JSON_OBJECT('65', _milk_lactose),
        JSON_OBJECT('63', _milk_butter_fat),
        JSON_OBJECT('61', ifnull( _milk_pm_litres,0)),
		JSON_OBJECT('62', ifnull( @milk_composite_litres,0)),
        
        JSON_OBJECT('235', ''),
        JSON_OBJECT('102', ifnull( _milk_sample_type_id,0)),       
        JSON_OBJECT('167', ifnull( _milking_notes,'')),
        JSON_OBJECT('219', ''),
        JSON_OBJECT('220', 0),
        JSON_OBJECT('218', ''),
        JSON_OBJECT('164', ''),
        JSON_OBJECT('221', ifnull( _days_in_milk,0))
	);  
     UPDATE core_animal_event  SET testday_no = _testday_no,lactation_id =_lactation_id,lactation_number =_lactation_number,event_date =_milk_date,data_collection_date =_milk_date,field_agent_id =_field_agent_id,
     additional_attributes =@additional_attributes,updated_at = CURDATE(),updated_by =_updated_by
     where id = _event_id;     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_pd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_pd`(_event_id integer,_service_date date,_isServiceDateKnown boolean, _time_examined time,_pd_results integer,_pd_stage integer,_body_score integer,_cost DECIMAL(10,2),_pd_method integer,_data_collection_date date,_field_agent_id integer,_updated_by integer)
BEGIN	 
    SET @additional_attributes = JSON_MERGE_PRESERVE(		
        JSON_OBJECT('128', ifnull( _isServiceDateKnown,0)),
        JSON_OBJECT('129', ifnull( _service_date,0)),
        JSON_OBJECT('130', ifnull( _time_examined,0)),
        JSON_OBJECT('131', ifnull( _pd_results,0)),
        JSON_OBJECT('132', ifnull( _pd_stage,0)),
		JSON_OBJECT('133', ifnull( _body_score,0)),
		JSON_OBJECT('134', ifnull( _cost,0)),
        JSON_OBJECT('135', ifnull( _pd_method,0))		  
	);     
     UPDATE core_animal_event SET event_date = _data_collection_date,data_collection_date = _data_collection_date,field_agent_id = _field_agent_id,
     additional_attributes = @additional_attributes ,updated_at = CURDATE(),updated_by = _updated_by
     WHERE id = _event_id;     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_sync` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_sync`(
_event_id integer,_sync_date date,_sync_number integer, _animal_parity integer,_sync_time time,_hormone_type integer,
_other_hormone_type varchar(100),_hormone_source integer,_other_hormone_source varchar(100),_sync_cost DECIMAL(10,2),
_sync_person integer,_sync_other_person varchar(100),_sync_person_phone varchar(30),
_field_agent_id integer,_updated_by integer)
BEGIN	
    SET @additional_attributes = JSON_MERGE_PRESERVE(		
        JSON_OBJECT('117', ifnull( _sync_number,0)),
        JSON_OBJECT('118', ifnull( _animal_parity,0)),
        JSON_OBJECT('119', ifnull( _sync_time,0)),
        JSON_OBJECT('120', ifnull( _hormone_type,0)),
        JSON_OBJECT('121', ifnull( _other_hormone_type,'')),
		JSON_OBJECT('122', ifnull( _hormone_source,0)),
		JSON_OBJECT('123', ifnull( _other_hormone_source,'')),
        JSON_OBJECT('124', ifnull( _sync_cost,0)),
        JSON_OBJECT('125', ifnull( _sync_person,0)),
		JSON_OBJECT('126', ifnull( _sync_other_person,'')),
        JSON_OBJECT('127', ifnull( _sync_person_phone,0))
	);     
     UPDATE core_animal_event SET event_date = _sync_date,data_collection_date = _sync_date,field_agent_id = _field_agent_id,
     additional_attributes = @additional_attributes,updated_at = CURDATE(),updated_by = _updated_by
     where id = _event_id;     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_event_weight` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_event_weight`(_event_id integer,_body_length float,_heart_girth float,_weight float,_body_score integer,_data_collection_date date,_field_agent_id integer,_updated_by integer)
BEGIN  
    SET @additional_attributes = JSON_MERGE_PRESERVE(
    JSON_OBJECT('136', ifnull( _weight,0)),
    JSON_OBJECT('137', ifnull( _heart_girth,0)),
    JSON_OBJECT('138', ifnull( _body_length,0)),
    JSON_OBJECT('139', ifnull( _body_score,0))
    );  
     update core_animal_event set event_date = _data_collection_date,data_collection_date = _data_collection_date,field_agent_id = _field_agent_id, additional_attributes = @additional_attributes,updated_at = CURDATE(),updated_by = _updated_by where id  = _event_id;
     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_parameter_limit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_parameter_limit`(_limit integer, _category varchar(100),_description varchar(300),_min_value decimal(19,4),_max_value decimal(19,4),_is_active tinyint,_user int)
BEGIN
	update interface_limit_parameters set category = _category ,description = _description, min_value = _min_value ,max_value = _max_value, is_active = _is_active, updated_at = CURDATE(),updated_by = _user
	where id = _limit;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_parameter_local_settings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_parameter_local_settings`(_id VARCHAR(200),_key VARCHAR(200),_value VARCHAR(200),_is_active TINYINT,_description VARCHAR(300),_farm_id integer,_updated_by integer)
BEGIN
	 UPDATE interface_local_settings SET 
		`value`=_value, 
        `key`=_key,
        is_active = _is_active, 
        description = _description,
        farm_id = _farm_id,
        updated_by = _updated_by,
        updated_at = CURDATE() 
	WHERE id = _id;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_user_list_view` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_user_list_view`()
BEGIN	
	SELECT 
		users.id,
		users.name,
		users.username,
		users.phone,
		users.email,
		country.name as country,	
		roles.name as role,
		org.name as default_org
	FROM auth_users users 
	LEFT JOIN auth_roles roles on roles.id = users.id
	LEFT JOIN core_country country  on country.id = users.country_id 
	LEFT JOIN core_organization org on org.id = users.org_id
	WHERE STATUS = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_validate_batch_records_milking` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_validate_batch_records_milking`(_uuid varchar(250),_user_id integer)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'SQLException encountered' message; 
	SET @milk_limit_max = 0;
    SET @milk_limit_min = 0;
    SET @milk_limit_validation_active_status = ( SELECT is_active FROM interface_limit_parameters WHERE category = 'milk_amount_limits' LIMIT 1);
    SET @milk_limit_validation_active_status = IFNULL(@milk_limit_validation_active_status,0);
    
    SET @has_errors = 0;
    
    UPDATE interface_batch_upload_details SET notes  = '' WHERE uuid = _uuid;
     
     /*UPDATE lactation ID*/     
     UPDATE interface_batch_upload_details
     INNER JOIN
     ( SELECT animal_id,MAX(ID) lactation_id FROM core_animal_event 
     WHERE core_animal_event.event_type = 1 
     AND animal_id IN(SELECT animal_id FROM interface_batch_upload_details where uuid = _uuid)
     GROUP BY animal_id ) T
     ON interface_batch_upload_details.animal_id = T.animal_id
     SET interface_batch_upload_details.lactation_id = T.lactation_id
     WHERE interface_batch_upload_details.uuid = _uuid;
     
     /*Update days in milk*/
	 UPDATE interface_batch_upload_details a
     INNER JOIN core_animal_event  b
     ON a.lactation_id  = b.id
     SET a.days_in_milk = DATEDIFF(str_to_date(a.milk_date,'%d/%m/%Y'),b.event_date)      
     WHERE a.uuid = _uuid;
     
     /*Lactation Number*/
     UPDATE interface_batch_upload_details
     INNER JOIN
     ( SELECT animal_id,COUNT(ID) lactation_number FROM core_animal_event 
     WHERE core_animal_event.event_type = 1 
     AND animal_id IN(SELECT animal_id FROM interface_batch_upload_details where uuid = _uuid)
     GROUP BY animal_id ) T
     ON interface_batch_upload_details.animal_id = T.animal_id
     SET interface_batch_upload_details.lactation_number = T.lactation_number
     WHERE interface_batch_upload_details.uuid = _uuid;
     
     /* update Test Day No*/
     UPDATE interface_batch_upload_details
     LEFT JOIN
     ( SELECT lactation_id,COUNT(ID)+1 test_day_no FROM core_animal_event 
     WHERE core_animal_event.event_type = 2
     AND lactation_id IN(SELECT lactation_id FROM interface_batch_upload_details where uuid = _uuid)
     GROUP BY lactation_id  ) T
     ON interface_batch_upload_details.lactation_id = T.lactation_id
     SET interface_batch_upload_details.test_day_no = IFNULL(T.test_day_no,1)
     WHERE interface_batch_upload_details.uuid = _uuid;
     
    
        
    IF @milk_limit_validation_active_status = 1 THEN
		SELECT  max_value,  min_value INTO @milk_limit_max, @milk_limit_min FROM interface_limit_parameters WHERE category = 'milk_amount_limits' LIMIT 1;
        -- check minimum milk limit
        UPDATE interface_batch_upload_details SET notes  = 3
        WHERE uuid = _uuid and (amount_morning < @milk_limit_min or amount_noon < @milk_limit_min or amount_afternoon < @milk_limit_min);  
        
         -- check maximum milk limit
        UPDATE interface_batch_upload_details SET notes  = concat(notes,',2')
        WHERE uuid = _uuid and (amount_morning > @milk_limit_max or amount_noon > @milk_limit_max or amount_afternoon > @milk_limit_max);  
        
    END IF; 
    
    -- check if animal_id exists
    UPDATE interface_batch_upload_details SET notes  = concat(notes,',4')  
    where uuid = _uuid and animal_id not in (select id from  core_animal );
    
    /* check if lactation id is set*/
    UPDATE interface_batch_upload_details SET notes  = concat(notes,',6')  
    where uuid = _uuid and lactation_id is null;
    
    -- update global batch
    
    UPDATE interface_batch_upload_details 
    SET status = CASE WHEN notes = '' THEN '2' ELSE 3 END      
    WHERE uuid = _uuid; 
    
    SET @has_failed  = (SELECT COUNT(*) FROM interface_batch_upload_details WHERE uuid = _uuid
    AND STATUS = 3);
    
    UPDATE interface_batch_uploads
    SET status = CASE WHEN @has_failed = 0 THEN '3' ELSE 2 END      
    WHERE uuid = _uuid;
    
    SELECT 'success' message;   
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_view_batch_upoad_milk_validate_step` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_view_batch_upoad_milk_validate_step`(_uuid varchar(250))
BEGIN 
	SELECT uploads.id as batch_id,
	batch_types.name as batch_type, 
	batch_stages.name as step,
    uploads.step as step_id,
    batch_status.id as batch_status_id,
	batch_status.name as batch_status,
    record_status.name as record_status,
	DATE_FORMAT(uploads.created_at,'%Y-%m-%d') as created_date,  
	DATE_FORMAT(uploads.created_at,'%H:%i:%s') as created_time, 
	ifnull(auth_users.name,'') as created_by,
	details.id as record_id,
	details.milk_date,
	details.animal_id,
	details.amount_morning,
	details.amount_noon,
	details.amount_afternoon,
    details.lactation_id,
    details.lactation_number,
    details.days_in_milk,
    details.test_day_no
	FROM interface_batch_uploads  uploads
	LEFT JOIN  interface_batch_types batch_types  on  uploads.batch_type = batch_types.id
	LEFT JOIN  interface_batch_stages batch_stages  on  uploads.step = batch_stages.step
	LEFT JOIN  interface_batch_status batch_status  on  uploads.status = batch_status.id   
	LEFT JOIN auth_users ON uploads.created_by = auth_users.id
	LEFT JOIN interface_batch_upload_details details ON uploads.uuid = details.uuid
     LEFT JOIN  interface_batch_records_status record_status  on  details.status = record_status.id
	WHERE uploads.uuid = _uuid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_view_calender_events` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_view_calender_events`(_org_id integer)
BEGIN 
	SELECT b.color,a.description 'desc', a.event_start_datetime 'end',a.title,a.uuid id, a.event_start_datetime 'start',a.all_day allDay 
    FROM interface_calender_events a
    LEFT JOIN interface_calender_status_colors b
    ON a.color = b.id 
    WHERE org_id =_org_id ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_view_user_profiles` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_view_user_profiles`(_user_id integer)
BEGIN
    SELECT 
        `users`.`id` AS `id`,
        `users`.`name` AS `name`,
        `users`.`username` AS `username`,
        `users`.`phone` AS `phone`,
        `users`.`email` AS `email`,
        `users`.`status` AS `status`,
        `users`.`timezone` AS `timezone`,
        `users`.`country_id` AS `country_id`,
        `country`.`name` AS `country`,
        `roles`.`name` AS `role`,
        `levels`.`name` AS `level`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`region_id`) AS `region`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`district_id`) AS `district`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`ward_id`) AS `ward`,
        (SELECT `unit`.`name`  FROM `country_units` `unit` WHERE `unit`.`id` = `users`.`village_id`) AS `village`,
       `users`.`profile_image` AS `profile_image`,
        `users`.`org_id` AS `org_id`,
        `organization`.`name` AS `organization`,
        `client`.`name` AS `client`,
        `users`.`password_hash` AS `password_hash`,
        `users`.`auth_key` AS `auth_key`
    FROM
        `auth_users` `users`
        LEFT JOIN `auth_roles` `roles` ON `users`.`role_id` = `roles`.`id`
        LEFT JOIN `auth_user_levels` `levels` ON `users`.`level_id` = `levels`.`id`
        LEFT JOIN `core_organization` `organization` ON `users`.`org_id` = `organization`.`id`
        LEFT JOIN `core_client` `client` ON `users`.`client_id` = `client`.`id`
        LEFT JOIN `core_country` `country` ON `country`.`id`=`users`.`country_id`
        WHERE users.id = _user_id
        LIMIT 1;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_weight_event_animal_analytics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_weight_event_animal_analytics`(_animal_id integer, _year year)
BEGIN

SELECT
  event_data.categ,
  round(sum(if(event_data.month = 1, event_data.categ_value, 0)),2)  AS Jan,
  round(sum(if(event_data.month = 2, event_data.categ_value, 0)),2)  AS Feb,
  round(sum(if(event_data.month = 3, event_data.categ_value, 0)),2)  AS Mar,
  round(sum(if(event_data.month = 4, event_data.categ_value, 0)),2)  AS Apr,
  round(sum(if(event_data.month = 5, event_data.categ_value, 0)),2)  AS May,
  round(sum(if(event_data.month = 6, event_data.categ_value, 0)),2)  AS Jun,
  round(sum(if(event_data.month = 7, event_data.categ_value, 0)),2)  AS Jul,
  round(sum(if(event_data.month = 8, event_data.categ_value, 0)),2)  AS Aug,  
  round(sum(if(event_data.month = 9, event_data.categ_value, 0)),2)  AS Sep,
  round(sum(if(event_data.month = 10, event_data.categ_value, 0)),2) AS Oct,
  round(sum(if(event_data.month = 11, event_data.categ_value, 0)),2) AS Nov,
  round(sum(if(event_data.month = 12, event_data.categ_value, 0)),2) AS 'Dec'
FROM 
(
	SELECT l.categ,l.month,avg(l.categ_value) as categ_value FROM (
	SELECT 'body_length' as categ,
	core_animal_event.event_date as date,MONTH(core_animal_event.event_date) AS month,
	REPLACE(JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."138"')),'null','') AS categ_value  
	FROM  core_animal_event WHERE core_animal_event.event_type = 6  AND core_animal_event.animal_id = _animal_id  
	AND YEAR(core_animal_event.event_date)  = _year) as l
	GROUP BY  l.MONTH
    
    UNION

    SELECT g.categ,g.month,avg(g.categ_value)  as categ_value FROM (
	SELECT 'heart_girth' as categ,
	core_animal_event.event_date as date,MONTH(core_animal_event.event_date) AS month,
	JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."137"')) AS categ_value   
	FROM  core_animal_event WHERE core_animal_event.event_type = 6  AND core_animal_event.animal_id = _animal_id  
	AND YEAR(core_animal_event.event_date) = _year )as g
	GROUP BY  g.MONTH
    
    UNION

	SELECT w.categ,w.month,avg(w.categ_value) as categ_value FROM (
	SELECT'weight_kg' as categ,
	core_animal_event.event_date as date,MONTH(core_animal_event.event_date) AS month,
	JSON_UNQUOTE(JSON_EXTRACT(core_animal_event.additional_attributes, '$."136"')) AS categ_value   
	FROM  core_animal_event WHERE core_animal_event.event_type = 6  AND core_animal_event.animal_id = _animal_id  
	AND YEAR(core_animal_event.event_date) = _year) as w
	GROUP BY  w.MONTH
) AS event_data
GROUP BY event_data.categ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `test`(_uuid varchar(250),_user_id integer)
BEGIN
	 /* update Test Day No*/
     UPDATE interface_batch_upload_details
     INNER JOIN
     ( SELECT lactation_id,ifnull(COUNT(ID),0)+1 test_day_no FROM core_animal_event 
     WHERE core_animal_event.event_type = 2
     AND lactation_id IN(SELECT lactation_id FROM interface_batch_upload_details where uuid = _uuid)
     GROUP BY lactation_id  ) T
     ON interface_batch_upload_details.lactation_id = T.lactation_id
     SET interface_batch_upload_details.test_day_no = T.test_day_no
     WHERE interface_batch_upload_details.uuid = _uuid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-27 10:16:31
