-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: adgg_uat
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `interface_ai_straws`
--

DROP TABLE IF EXISTS `interface_ai_straws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interface_ai_straws` (
  `id` int NOT NULL AUTO_INCREMENT,
  `straw_id` varchar(255) DEFAULT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `bull_tag_id` varchar(255) DEFAULT NULL,
  `bull_name` varchar(255) DEFAULT NULL,
  `breed` int DEFAULT NULL,
  `breed_composition` int DEFAULT NULL,
  `semen_source` varchar(255) DEFAULT NULL,
  `farm_name` varchar(255) DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `ejaculation_number` varchar(255) DEFAULT NULL,
  `production_date` timestamp NULL DEFAULT NULL,
  `specification` varchar(10) DEFAULT NULL,
  `is_active` tinyint DEFAULT '1',
  `additional_info` varchar(255) DEFAULT NULL,
  `org_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interface_ai_straws`
--

LOCK TABLES `interface_ai_straws` WRITE;
/*!40000 ALTER TABLE `interface_ai_straws` DISABLE KEYS */;
INSERT INTO `interface_ai_straws` VALUES (1,'ILRI','Test','Test','Test',1,1,'Test','Test','Test','Test','2020-09-30 21:00:00','N',1,'Test',5,559,'2020-10-01 12:55:31',559,'2020-10-02 08:49:18'),(2,'Test','Test','Test','Test',1,1,'Test','Test','Test','Test','2020-09-30 21:00:00','N',1,'Test',5,559,'2020-10-01 13:26:46',559,'2020-10-02 10:03:57'),(3,'KALRO','KALRO','KALRO','KALRO',14,5,'KALRO','KALRO','KALRO','KALRO','2020-10-28 21:00:00','X',1,'KALRO',5,559,'2020-10-01 13:31:06',559,'2020-10-01 15:27:44'),(4,'TEST','TEST','TEST','TEST',15,1,'KAGRIC','TEST','TEST','TEST','2020-10-28 21:00:00','S',0,'TEST',5,559,'2020-10-01 13:46:35',559,'2020-10-02 10:40:13'),(5,'Y','Y','X','X',16,3,'Y','Y','X','X','2020-11-04 21:00:00','S',0,'X',5,559,'2020-10-01 15:30:05',559,'2020-10-07 11:49:12'),(6,'xxxxxx','xxxxx','xxxxxx','xxxxxxxxxx',16,5,'xxxxx','xxxxx','xxxx','xxxxxxxxxx','2020-10-27 21:00:00','S',0,'xxxxxxxxx',5,559,'2020-10-02 14:05:35',559,'2020-10-07 11:48:44'),(7,'xx','xx','xx','xx',18,1,'xxx','xx','xx','xx','2020-10-28 21:00:00','N',0,'xx',5,559,'2020-10-02 14:57:31',559,'2020-10-07 11:48:53'),(8,'ss','','','',NULL,NULL,'sss','','ss','','2020-10-27 21:00:00',NULL,0,'',5,559,'2020-10-02 15:03:50',559,'2020-10-07 11:49:04');
/*!40000 ALTER TABLE `interface_ai_straws` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-27 10:16:25
