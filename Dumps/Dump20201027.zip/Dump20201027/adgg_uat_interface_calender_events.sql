-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: adgg_uat
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `interface_calender_events`
--

DROP TABLE IF EXISTS `interface_calender_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interface_calender_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `event_start_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `event_end_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `all_day` tinyint DEFAULT '0',
  `org_id` int DEFAULT NULL,
  `color` int DEFAULT NULL,
  `uuid` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interface_calender_events`
--

LOCK TABLES `interface_calender_events` WRITE;
/*!40000 ALTER TABLE `interface_calender_events` DISABLE KEYS */;
INSERT INTO `interface_calender_events` VALUES (1,'Event title','Event description','2020-09-10 17:00:00','2020-09-10 17:00:00',0,5,1,'1e04adaf-f387-11ea-b2ef-b00cd1505cfb','2020-09-10 17:00:23',559,NULL,NULL),(2,'Event title','Event description','2020-09-10 17:05:00','2020-09-10 17:05:00',0,5,1,'cd7474e7-f387-11ea-b2ef-b00cd1505cfb','2020-09-10 17:05:18',559,NULL,NULL),(3,'Event title','Event description','2020-09-10 17:08:00','2020-09-10 17:08:00',0,5,1,'3ce6306d-f388-11ea-b2ef-b00cd1505cfb','2020-09-10 17:08:25',559,NULL,NULL),(4,'Event title','Event description','2020-09-10 17:09:00','2020-09-10 17:09:00',0,5,1,'72b57dec-f388-11ea-b2ef-b00cd1505cfb','2020-09-10 17:09:55',559,NULL,NULL),(5,'Event title','Event description','2020-09-10 17:10:00','2020-09-10 17:10:00',0,5,1,'8b5c5387-f388-11ea-b2ef-b00cd1505cfb','2020-09-10 17:10:36',559,NULL,NULL),(6,'Event title','Event description','2020-09-10 17:10:00','2020-09-10 17:10:00',0,5,1,'920950c3-f388-11ea-b2ef-b00cd1505cfb','2020-09-10 17:10:47',559,NULL,NULL),(7,'Event title','Event description','2020-09-10 17:10:00','2020-09-10 17:10:00',0,5,1,'98b8d799-f388-11ea-b2ef-b00cd1505cfb','2020-09-10 17:10:59',559,NULL,NULL),(8,'Event title','Event description','2020-09-11 05:11:00','2020-09-11 05:11:00',0,5,1,'afc22480-f388-11ea-b2ef-b00cd1505cfb','2020-09-10 17:11:37',559,NULL,NULL),(9,'Event title','Event description','2020-09-10 17:11:00','2020-09-10 17:11:00',1,5,1,'b6e7b115-f388-11ea-b2ef-b00cd1505cfb','2020-09-10 17:11:49',559,NULL,NULL),(10,'Test Test','Test Test','2020-09-10 14:27:29','2020-09-10 14:27:29',1,5,1,'cf32e6b2-f3a9-11ea-b2ef-b00cd1505cfb','2020-09-10 21:08:43',559,NULL,NULL),(11,'Hello','Hello Description','2020-09-21 07:27:00','2020-09-21 07:27:00',1,5,1,'00ba3da9-fbdc-11ea-8a24-b00cd1505cfb','2020-09-21 07:28:11',559,NULL,NULL),(12,'Event title','Event description','2020-10-16 07:17:00','2020-10-16 07:17:00',0,5,1,'a6f2804c-0f7f-11eb-8f13-b00cd1505cfb','2020-10-16 07:17:30',559,NULL,NULL);
/*!40000 ALTER TABLE `interface_calender_events` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-27 10:16:26
